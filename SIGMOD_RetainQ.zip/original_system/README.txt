Original producer/compiler and fresh-process verifier are preserved byte for byte.
The focused study does not import either module. Their hashes are recorded here.
The prior completed confirmatory run, including all measured results, is preserved in the evidence ZIP.
To reproduce that existing full system study separately:
  python -m pip install -r original_system/requirements.txt
  python original_system/reproduce.py --mode CONFIRMATORY --output-root original_runs
SMOKE is a setup check only. The new focused study is reproduced with study.py.
The convenience driver invokes the same seven-stage API sequence as the original notebook; its help/import is checked, not a new full-system experiment run.
