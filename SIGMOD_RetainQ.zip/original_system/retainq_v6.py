from __future__ import annotations
import argparse, collections, csv, hashlib, io, itertools, json, math, os, platform
import random, re, shutil, statistics, subprocess, sys, tempfile, time, traceback, urllib.request, zipfile
from pathlib import Path
from fractions import Fraction
import duckdb
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import psutil
VERSION = 'RetainQ-SIGMOD-V6.1'
THREADS = 2
def canonical_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()

def digest_value(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def download_file(url, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "RetainQ-SIGMOD-V6/1.0"})
    with urllib.request.urlopen(request, timeout=60) as response, open(temporary, "wb") as handle:
        shutil.copyfileobj(response, handle, length=1024 * 1024)
    os.replace(temporary, path)
    return path

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False).encode())

def read_json(path):
    return json.loads(Path(path).read_text())

def compositions(g, k, lo=None, hi=None):
    lo = [0] * g if lo is None else list(map(int, lo))
    hi = [k] * g if hi is None else list(map(int, hi))
    suffix_lo = [0] * (g + 1)
    suffix_hi = [0] * (g + 1)
    for i in range(g - 1, -1, -1):
        suffix_lo[i] = suffix_lo[i + 1] + lo[i]
        suffix_hi[i] = suffix_hi[i + 1] + hi[i]

    def rec(i, remaining, prefix):
        if i == g:
            if remaining == 0:
                yield tuple(prefix)
            return
        low = max(lo[i], remaining - suffix_hi[i + 1])
        high = min(hi[i], remaining - suffix_lo[i + 1])
        for value in range(low, high + 1):
            prefix.append(value)
            yield from rec(i + 1, remaining - value, prefix)
            prefix.pop()

    yield from rec(0, k, [])

def bounded_policy_count(g, k, lo, hi):
    counts = [0] * (k + 1)
    counts[0] = 1
    for index in range(g):
        next_counts = [0] * (k + 1)
        for total, count in enumerate(counts):
            if not count:
                continue
            for value in range(lo[index], min(hi[index], k - total) + 1):
                next_counts[total + value] += count
        counts = next_counts
    return counts[k]

def quota_row(q, k):
    return [int(r <= q[g]) for g in range(len(q)) for r in range(1, k + 1)]

def modular_rank(matrix, prime=1_000_000_007):
    if not matrix:
        return 0
    rows = [list(map(lambda x: int(x) % prime, row)) for row in matrix]
    m = len(rows)
    n = len(rows[0])
    rank = 0
    for col in range(n):
        pivot = next((i for i in range(rank, m) if rows[i][col]), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        inv = pow(rows[rank][col], prime - 2, prime)
        rows[rank] = [(x * inv) % prime for x in rows[rank]]
        for i in range(m):
            if i != rank and rows[i][col]:
                factor = rows[i][col]
                rows[i] = [(rows[i][j] - factor * rows[rank][j]) % prime for j in range(n)]
        rank += 1
        if rank == m:
            break
    return rank

def exact_rank(matrix):
    if not matrix:
        return 0
    rows = [[Fraction(value) for value in row] for row in matrix]
    rank = 0
    for column in range(len(rows[0])):
        pivot = next((index for index in range(rank, len(rows)) if rows[index][column]), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        scale = rows[rank][column]
        rows[rank] = [value / scale for value in rows[rank]]
        for index in range(len(rows)):
            if index == rank or not rows[index][column]:
                continue
            factor = rows[index][column]
            rows[index] = [left - factor * right for left, right in zip(rows[index], rows[rank])]
        rank += 1
        if rank == len(rows):
            break
    return rank

def generate_duckdb_sql(basis_terms, rank, metrics):
    values = ",\n".join(
        f"({int(term['basis_id'])},{int(term['group'])},{int(term['rank'])},{int(term['coefficient'])})"
        for term in basis_terms
    )
    setup = f"""CREATE OR REPLACE TABLE retainq_basis_terms AS
SELECT * FROM (VALUES
{values}
) AS terms(basis_id, group_id, rank_position, coefficient);
CREATE TABLE IF NOT EXISTS retained_state(
metric_id INTEGER,
basis_id INTEGER,
value BIGINT,
PRIMARY KEY(metric_id, basis_id)
);
INSERT INTO retained_state
SELECT metric_id, basis_id, 0::BIGINT
FROM range({metrics}) AS metric(metric_id)
CROSS JOIN range({rank}) AS basis(basis_id)
ON CONFLICT(metric_id, basis_id) DO NOTHING;
CREATE TABLE IF NOT EXISTS retainq_ingested_rounds(round_id BIGINT PRIMARY KEY);"""
    atom_parts = []
    for metric in range(metrics):
        atom_parts.append(
            f"SELECT group_id, rank_position, {metric}::INTEGER AS metric_id, SUM(metric_{metric})::BIGINT AS atom_value "
            "FROM retainq_delta JOIN retainq_new_rounds USING(round_id) GROUP BY group_id, rank_position"
        )
    atoms = "\nUNION ALL\n".join(atom_parts)
    update = f"""BEGIN TRANSACTION;
CREATE OR REPLACE TEMP TABLE retainq_new_rounds AS
SELECT DISTINCT delta.round_id
FROM retainq_delta AS delta
WHERE NOT EXISTS (
SELECT 1 FROM retainq_ingested_rounds AS ledger WHERE ledger.round_id=delta.round_id
);
WITH atom_updates AS (
{atoms}
), basis_updates AS (
SELECT atoms.metric_id, terms.basis_id,
SUM(atoms.atom_value * terms.coefficient)::BIGINT AS delta
FROM atom_updates AS atoms
JOIN retainq_basis_terms AS terms USING(group_id, rank_position)
GROUP BY atoms.metric_id, terms.basis_id
)
UPDATE retained_state AS state
SET value=state.value + updates.delta
FROM basis_updates AS updates
WHERE state.metric_id=updates.metric_id AND state.basis_id=updates.basis_id;
INSERT INTO retainq_ingested_rounds
SELECT round_id FROM retainq_new_rounds
ON CONFLICT(round_id) DO NOTHING;
DROP TABLE retainq_new_rounds;
COMMIT;"""
    return {"setup": setup, "update": update, "sha256": digest_value({"setup": setup, "update": update})}

class UnionFind:
    def __init__(self, items):
        self.parent = {item: item for item in items}
        self.size = {item: 1 for item in items}

    def find(self, item):
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left, right):
        left = self.find(left)
        right = self.find(right)
        if left == right:
            return False
        if self.size[left] < self.size[right]:
            left, right = right, left
        self.parent[right] = left
        self.size[left] += self.size[right]
        return True

def feasible_base(lo, hi, k):
    q = list(lo)
    remaining = k - sum(q)
    for g in range(len(q)):
        delta = min(remaining, hi[g] - q[g])
        q[g] += delta
        remaining -= delta
    if remaining:
        raise ValueError("infeasible bounded quota family")
    return q

def allocate_witness(g, h, r, s, lo, hi, k):
    q = list(lo)
    q[g] = r - 1
    q[h] = s
    remaining = k - sum(q)
    for j in range(len(q)):
        if j in (g, h):
            continue
        delta = min(remaining, hi[j] - q[j])
        q[j] += delta
        remaining -= delta
    if remaining or any(q[j] < lo[j] or q[j] > hi[j] for j in range(len(q))):
        raise ValueError("edge witness construction failed")
    return q

def _compile_structural(contract):
    g = int(contract["G"])
    k = int(contract["K"])
    lo = list(map(int, contract["lo"]))
    hi = list(map(int, contract["hi"]))
    if k < 1 or len(lo) != g or len(hi) != g:
        raise ValueError("invalid contract dimensions")
    if any(lo[i] < 0 or lo[i] > hi[i] or hi[i] > k for i in range(g)):
        raise ValueError("invalid bounds")
    if sum(lo) > k or sum(hi) < k:
        raise ValueError("infeasible bounds")
    m = [max(lo[i], k - sum(hi[j] for j in range(g) if j != i)) for i in range(g)]
    big_m = [min(hi[i], k - sum(lo[j] for j in range(g) if j != i)) for i in range(g)]
    vertices = [(i, r) for i in range(g) for r in range(m[i] + 1, big_m[i] + 1)]
    mandatory_count = sum(m)
    unreachable_count = sum(k - value for value in big_m)
    vertex_set = set(vertices)
    # Canonical lexicographic undirected edges; retain witnesses only for forest edges.
    edge_witnesses = {}
    edge_count = 0
    uf = UnionFind(vertices)
    forest = []
    sum_lo, sum_hi = sum(lo), sum(hi)
    for receiver in range(g):
        for r in range(m[receiver] + 1, big_m[receiver] + 1):
            for donor in range(receiver + 1, g):
                residual_lo = sum_lo - lo[receiver] - lo[donor]
                residual_hi = sum_hi - hi[receiver] - hi[donor]
                for s in range(m[donor] + 1, big_m[donor] + 1):
                    residual = k - (r - 1) - s
                    if residual_lo <= residual <= residual_hi:
                        edge_count += 1
                        edge = ((receiver, r), (donor, s))
                        if uf.union(*edge):
                            forest.append(edge)
                            edge_witnesses[edge] = allocate_witness(receiver, donor, r, s, lo, hi, k)
    components = {}
    for vertex in vertices:
        components.setdefault(uf.find(vertex), []).append(vertex)
    normalized_components = sorted([sorted(values) for values in components.values()])
    component_id = {vertex: i for i, values in enumerate(normalized_components) for vertex in values}
    forest_adj = {vertex: [] for vertex in vertices}
    for left, right in forest:
        forest_adj[left].append(right)
        forest_adj[right].append(left)
    roots = []
    oriented = []
    for values in normalized_components:
        root = min(values)
        roots.append(root)
        queue = [root]
        seen = {root}
        while queue:
            parent = queue.pop(0)
            for child in sorted(forest_adj[parent]):
                if child in seen:
                    continue
                seen.add(child)
                queue.append(child)
                oriented.append((child, parent))
    q0 = feasible_base(lo, hi, k)
    basis_terms = [{"basis_id": 0, "group": i, "rank": r, "coefficient": 1} for i in range(g) for r in range(1, q0[i] + 1)]
    oriented_records = []
    for basis_id, (child, parent) in enumerate(oriented, 1):
        basis_terms.append({"basis_id": basis_id, "group": child[0], "rank": child[1], "coefficient": 1})
        basis_terms.append({"basis_id": basis_id, "group": parent[0], "rank": parent[1], "coefficient": -1})
        key = tuple(sorted((child, parent)))
        oriented_records.append({
            "basis_id": basis_id,
            "child": list(child),
            "parent": list(parent),
            "witness": list(edge_witnesses[key]),
        })
    rank = 1 + len(vertices) - len(normalized_components)
    pruned_dim = len(vertices) + int(mandatory_count > 0)
    metrics = int(contract.get("metrics", 1))
    value_bound = int(contract.get("value_bound", 1))
    horizon = int(contract.get("horizon", 1))
    word_bits = int(contract.get("word_bits", 64))
    if metrics < 1 or value_bound < 0 or horizon < 1 or word_bits < 2:
        raise ValueError("invalid numeric contract")
    overflow_horizon = (2 ** (word_bits - 1) - 1) // max(1, k * value_bound)
    if horizon > overflow_horizon:
        raise OverflowError("declared horizon exceeds fixed-width certificate")
    contract_payload = {
        "G": g,
        "K": k,
        "lo": lo,
        "hi": hi,
        "metrics": metrics,
        "value_bound": value_bound,
        "horizon": horizon,
        "arithmetic": "integer",
        "family": "bounded_fixed_capacity",
    }
    decoder = {
        "schema_version": 1,
        "q0": q0,
        "vertices": [list(x) for x in vertices],
        "roots": [list(x) for x in roots],
        "oriented_edges": oriented_records,
    }
    generated_sql = generate_duckdb_sql(basis_terms, rank, metrics)
    structure_payload = {
        "m": m,
        "M": big_m,
        "vertices": [list(x) for x in vertices],
        "components": [[list(x) for x in values] for values in normalized_components],
        "edge_count": edge_count,
    }
    certificate = {
        "schema_version": 2,
        "theorem": "quota_transfer_rank_v2",
        "encoding": "implicit_ranges_explicit_forest",
        "contract_sha256": digest_value(contract_payload),
        "decoder_sha256": digest_value(decoder),
        "basis_terms_sha256": digest_value(basis_terms),
        "structure_sha256": digest_value(structure_payload),
        "generated_sql_sha256": generated_sql["sha256"],
        "rank": rank,
        "raw_dimension": g * k,
        "pruned_dimension": pruned_dim,
        "variable_count": len(vertices),
        "mandatory_count": mandatory_count,
        "unreachable_count": unreachable_count,
        "component_count": len(normalized_components),
        "graph_edge_count": edge_count,
        "word_bits": word_bits,
        "value_bound": value_bound,
        "overflow_horizon": overflow_horizon,
        "state_sha256": None,
        "metadata_sha256": None,
    }
    return {
        "contract": contract_payload,
        "decoder": decoder,
        "certificate": certificate,
        "basis_terms": basis_terms,
        "q0": q0,
        "m": m,
        "M": big_m,
        "vertices": [list(x) for x in vertices],
        "components": [[list(x) for x in values] for values in normalized_components],
        "oriented_edges": oriented_records,
        "generated_sql": generated_sql,
        "rank": rank,
        "raw_dimension": g * k,
        "pruned_dimension": pruned_dim,
        "variable_count": len(vertices),
        "mandatory_count": mandatory_count,
        "unreachable_count": unreachable_count,
        "component_count": len(normalized_components),
        "edge_count": edge_count,
        "policy_count": bounded_policy_count(g, k, lo, hi),
    }

def decoder_coefficients(decoder, q):
    q0 = decoder["q0"]
    vertices = [tuple(x) for x in decoder["vertices"]]
    roots = {tuple(x) for x in decoder["roots"]}
    parent = {}
    basis = {}
    children = {vertex: [] for vertex in vertices}
    for edge in decoder["oriented_edges"]:
        child = tuple(edge["child"])
        par = tuple(edge["parent"])
        parent[child] = par
        basis[child] = int(edge["basis_id"])
        children[par].append(child)
    depth = {}
    queue = [(root, 0) for root in roots]
    while queue:
        vertex, d = queue.pop(0)
        depth[vertex] = d
        queue.extend((child, d + 1) for child in children[vertex])
    subtree = {vertex: int(vertex[1] <= q[vertex[0]]) - int(vertex[1] <= q0[vertex[0]]) for vertex in vertices}
    coefficients = {0: 1}
    for vertex in sorted(vertices, key=lambda x: depth[x], reverse=True):
        if vertex in roots:
            if subtree[vertex] != 0:
                raise ValueError("decoder component balance failed")
            continue
        coefficients[basis[vertex]] = subtree[vertex]
        subtree[parent[vertex]] += subtree[vertex]
    return coefficients

def prepare_synthetic(path, rows, rounds, base_groups, metrics):
    path = Path(path)
    if path.exists():
        return {"path": str(path), "cached": True, "rows": pq.ParquetFile(path).metadata.num_rows, "sha256": sha256_file(path), "elapsed_seconds": 0.0}
    started = time.perf_counter()
    path.parent.mkdir(parents=True, exist_ok=True)
    row_id = np.arange(rows, dtype=np.int64)
    data = {
        "row_id": row_id,
        "round_id": (row_id % rounds).astype(np.int32),
        "group_base": ((row_id // rounds) % base_groups).astype(np.int16),
        "candidate_id": row_id,
        "score": ((row_id * np.int64(1_103_515_245) + np.int64(12_345)) % np.int64(1_000_003)).astype(np.int64),
    }
    for metric in range(metrics):
        data[f"metric_{metric}"] = ((row_id * np.int64(97 + 2 * metric) + np.int64(31 * metric + 7)) % np.int64(101)).astype(np.int64)
    table = pa.table(data)
    pq.write_table(table, path, compression="zstd", row_group_size=100_000)
    return {"path": str(path), "cached": False, "rows": rows, "sha256": sha256_file(path), "elapsed_seconds": time.perf_counter() - started}

def prepare_acs(path, raw_root, mode):
    path = Path(path)
    state = "DE" if mode == "SMOKE" else "CA"
    if path.exists():
        cached_rows = pq.ParquetFile(path).metadata.num_rows
        return {"path": str(path), "cached": True, "rows": cached_rows, "available_filtered_rows": cached_rows, "state": state, "sha256": sha256_file(path), "elapsed_seconds": 0.0}
    started = time.perf_counter()
    from folktables import ACSDataSource
    Path(raw_root).mkdir(parents=True, exist_ok=True)
    cap = 20_000 if mode == "SMOKE" else None
    rounds = 10 if mode == "SMOKE" else 50
    source = ACSDataSource(survey_year="2018", horizon="1-Year", survey="person", root_dir=str(raw_root))
    frame = source.get_data(states=[state], download=True)
    columns = ["AGEP", "SCHL", "WKHP", "PINCP", "OCCP", "ESR", "SEX"]
    frame = frame[columns].dropna()
    frame = frame[(frame["OCCP"] > 0) & (frame["WKHP"] >= 0)]
    available_filtered_rows = len(frame)
    if cap is not None and len(frame) > cap:
        frame = frame.sample(n=cap, random_state=20260801)
    frame = frame.sort_index().reset_index(drop=False)
    row_id = np.arange(len(frame), dtype=np.int64)
    occ = frame["OCCP"].to_numpy(dtype=np.int64)
    age = frame["AGEP"].to_numpy(dtype=np.int64)
    school = frame["SCHL"].to_numpy(dtype=np.int64)
    hours = frame["WKHP"].to_numpy(dtype=np.int64)
    income = np.clip(frame["PINCP"].to_numpy(dtype=np.int64), 0, 200_000)
    score = school * 10_000 + hours * 100 + income // 100 - np.abs(age - 40)
    result = pa.table({
        "row_id": row_id,
        "round_id": (row_id % rounds).astype(np.int32),
        "group_base": np.minimum(occ // 2500, 3).astype(np.int16),
        "group_binary": np.clip(frame["SEX"].to_numpy(dtype=np.int64) - 1, 0, 1).astype(np.int16),
        "candidate_id": frame["index"].to_numpy(dtype=np.int64),
        "score": score.astype(np.int64),
        "metric_0": (frame["ESR"].to_numpy() == 1).astype(np.int64),
        "metric_1": (income // 1000).astype(np.int64),
    })
    path.parent.mkdir(parents=True, exist_ok=True)
    pq.write_table(result, path, compression="zstd", row_group_size=100_000)
    return {"path": str(path), "cached": False, "rows": len(frame), "available_filtered_rows": available_filtered_rows, "state": state, "sha256": sha256_file(path), "elapsed_seconds": time.perf_counter() - started}

def prepare_movielens(path, cache_root, mode):
    path = Path(path)
    cache_root = Path(cache_root)
    dataset_name = "ml-latest-small" if mode == "SMOKE" else "ml-25m"
    source_url = f"https://files.grouplens.org/datasets/movielens/{dataset_name}.zip"
    archive_path = cache_root / f"{dataset_name}.zip"
    checksum_path = cache_root / f"{dataset_name}.zip.md5"
    metadata_path = path.with_suffix(".metadata.json")
    if path.exists() and metadata_path.exists():
        metadata = read_json(metadata_path)
        metadata.update({"path": str(path), "cached": True, "sha256": sha256_file(path), "elapsed_seconds": 0.0})
        return metadata
    started = time.perf_counter()
    cache_root.mkdir(parents=True, exist_ok=True)
    if not checksum_path.exists():
        download_file(source_url + ".md5", checksum_path)
    checksum_matches = re.findall(r"(?i)\b[0-9a-f]{32}\b", checksum_path.read_text())
    if len(checksum_matches) != 1:
        raise ValueError("invalid MovieLens checksum file")
    expected_md5 = checksum_matches[0].lower()
    if not archive_path.exists():
        download_file(source_url, archive_path)
    observed_md5 = md5_file(archive_path)
    if observed_md5 != expected_md5:
        archive_path.unlink(missing_ok=True)
        raise ValueError("MovieLens archive checksum mismatch")
    extracted_root = cache_root / dataset_name
    ratings_path = extracted_root / "ratings.csv"
    movies_path = extracted_root / "movies.csv"
    if not ratings_path.exists() or not movies_path.exists():
        with zipfile.ZipFile(archive_path) as archive:
            members = {f"{dataset_name}/ratings.csv", f"{dataset_name}/movies.csv"}
            if not members.issubset(set(archive.namelist())):
                raise ValueError("MovieLens archive schema mismatch")
            for member in sorted(members):
                archive.extract(member, cache_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(".part.parquet")
    temporary_path.unlink(missing_ok=True)
    ratings_literal = "'" + str(ratings_path).replace("'", "''") + "'"
    output_literal = "'" + str(temporary_path).replace("'", "''") + "'"
    connection = duckdb.connect(":memory:")
    connection.execute("PRAGMA threads=1")
    connection.execute("CREATE TABLE movies AS SELECT movieId::BIGINT AS movieId, title::VARCHAR AS title FROM read_csv_auto(?, header=true)", [str(movies_path)])
    connection.execute(
        """
        CREATE TABLE movie_groups AS
        SELECT movieId,
               try_cast(regexp_extract(title, '\\(([0-9]{4})\\)$', 1) AS INTEGER) AS release_year
        FROM movies
        """
    )
    connection.execute(
        f"""
        COPY (
            SELECT (row_number() OVER () - 1)::BIGINT AS row_id,
                   (dense_rank() OVER (ORDER BY r.userId) - 1)::BIGINT AS round_id,
                   CASE
                       WHEN coalesce(g.release_year, 1900) < 1980 THEN 0
                       WHEN g.release_year < 1990 THEN 1
                       WHEN g.release_year < 2000 THEN 2
                       WHEN g.release_year < 2010 THEN 3
                       ELSE 4
                   END::SMALLINT AS group_base,
                   CASE
                       WHEN coalesce(g.release_year, 1900) < 2000 THEN 0
                       ELSE 1
                   END::SMALLINT AS group_binary,
                   r.movieId::BIGINT AS candidate_id,
                   round(r.rating * 2)::BIGINT AS score,
                   round(r.rating * 2)::BIGINT AS metric_0,
                   greatest(0, least(200, coalesce(g.release_year, 1900) - 1900))::BIGINT AS metric_1
            FROM read_csv_auto({ratings_literal}, header=true) AS r
            JOIN movie_groups AS g USING (movieId)
        ) TO {output_literal} (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 100000)
        """,
    )
    connection.close()
    os.replace(temporary_path, path)
    parquet_connection = duckdb.connect(":memory:")
    rows, users = parquet_connection.execute("SELECT count(*), count(DISTINCT round_id) FROM read_parquet(?)", [str(path)]).fetchone()
    parquet_connection.close()
    metadata = {
        "path": str(path),
        "cached": False,
        "dataset": dataset_name,
        "source_url": source_url,
        "archive_md5": observed_md5,
        "rows": int(rows),
        "rounds": int(users),
        "groups": 5,
        "binary_groups": 2,
        "metrics": 2,
        "group_definition": "movie release-era buckets",
        "binary_group_definition": "release year before 2000 versus 2000 or later",
        "round_definition": "MovieLens user",
        "sha256": sha256_file(path),
        "elapsed_seconds": time.perf_counter() - started,
    }
    write_json(metadata_path, {key: value for key, value in metadata.items() if key not in {"path", "cached", "sha256", "elapsed_seconds"}})
    return metadata

# Strict public interface; source atomization and aggregate maintenance are distinct stages.
KINDS = ['RawRankMarginals', 'PrunedRankMarginals', 'AllPolicyMaterialise', 'RetainQForest']
FORMATS = ['binary', 'duckdb']
INT64_MAX = 2**63 - 1


def strict_int(value, label, low=0):
    if type(value) is not int or value < low:
        raise ValueError(f'{label} must be a Python integer >= {low}')
    return value


def validate_contract(raw):
    if type(raw) is not dict:
        raise ValueError('contract must be a JSON object')
    required = {'G','K','lo','hi','metrics','value_bound','horizon'}
    allowed = required | {'word_bits','family','arithmetic','granularity','semantics'}
    if not required <= set(raw) or set(raw) - allowed:
        raise ValueError(f'contract fields: missing={required-set(raw)}, extra={set(raw)-allowed}')
    c = dict(raw)
    for key in ['G','K','metrics','horizon']:
        strict_int(c[key], key, 1)
    strict_int(c['value_bound'], 'value_bound')
    if c.get('word_bits', 64) != 64 or type(c.get('word_bits',64)) is not int:
        raise ValueError('only checked signed 64-bit state is implemented')
    for key, wanted in [('family','bounded_fixed_capacity'),('arithmetic','integer'),('granularity','cumulative')]:
        if c.get(key, wanted) != wanted:
            raise ValueError(f'unsupported {key}')
        c[key] = wanted
    c['word_bits'] = 64
    for key in ['lo','hi']:
        if type(c[key]) is not list or len(c[key]) != c['G']:
            raise ValueError('quota bound length mismatch')
        for x in c[key]: strict_int(x, key)
    if any(l > u or u > c['K'] for l,u in zip(c['lo'],c['hi'])):
        raise ValueError('invalid quota interval')
    if sum(c['lo']) > c['K'] or sum(c['hi']) < c['K']:
        raise ValueError('infeasible quota family')
    if c['horizon'] > INT64_MAX // max(1,c['K']*c['value_bound']):
        raise OverflowError('declared capacity/value/horizon exceeds signed 64-bit state')
    default = {'ranking':'score DESC, candidate_id ASC', 'grouping':'canonical group_id',
               'observables':[f'metric_{i}' for i in range(c['metrics'])],
               'rounds':'complete immutable sealed rounds',
               'missing_positions':'zero; shortfall is not redistributed'}
    semantics = c.get('semantics', default)
    if type(semantics) is not dict or set(semantics) != set(default):
        raise ValueError('incomplete canonical semantic metadata')
    if semantics['ranking'] != default['ranking'] or semantics['rounds'] != default['rounds'] or semantics['missing_positions'] != default['missing_positions']:
        raise ValueError('unsupported canonical ranking/round/missing-position semantics')
    if type(semantics['grouping']) is not str or not semantics['grouping']:
        raise ValueError('group mapping description required')
    obs = semantics['observables']
    if type(obs) is not list or len(obs) != c['metrics'] or any(type(x) is not str or not x for x in obs):
        raise ValueError('one observable definition is required per metric')
    c['semantics'] = semantics
    return json.loads(json.dumps(c))


def compile_contract(raw):
    c = validate_contract(raw)
    result = _compile_structural(c)
    result['contract'] = c
    result['certificate']['contract_sha256'] = digest_value(c)
    widths = [M-m for m,M in zip(result['m'],result['M'])]
    active = sum(w>0 for w in widths)
    simple_rank = 1 if active == 0 else (max(widths)+1 if active == 2 else sum(widths))
    if active == 1 or simple_rank != result['rank']:
        raise AssertionError('bounded-box closed form disagrees with streamed graph')
    result['effective_variable_groups'] = active
    result['closed_form_rank'] = simple_rank
    return result


def check_policy(c, q):
    if not isinstance(q,(list,tuple)) or len(q) != c['G'] or any(type(x) is not int for x in q):
        raise ValueError('policy must have G integer quotas')
    if sum(q) != c['K'] or any(x<l or x>u for x,l,u in zip(q,c['lo'],c['hi'])):
        raise ValueError('policy outside declared contract')
    return tuple(q)


def make_plan(compiled, kind, cap=10000):
    if kind not in KINDS: raise ValueError('unknown representation')
    c = compiled['contract']
    if kind == 'RetainQForest':
        decoder = dict(compiled['decoder'])
        decoder.update(kind=kind, dimension=compiled['rank'])
    else:
        dim = {'RawRankMarginals':compiled['raw_dimension'], 'PrunedRankMarginals':compiled['pruned_dimension'],
               'AllPolicyMaterialise':compiled['policy_count']}[kind]
        if kind == 'AllPolicyMaterialise' and dim > cap:
            raise ValueError(f'all-policy family exceeds explicit cap {cap}; not timed as a failure')
        decoder = {'schema_version':1,'kind':kind,'dimension':dim}
    return {'contract':c,'decoder':decoder,'compiled':compiled}


def check_atoms(plan, atoms):
    c=plan['contract']; a=np.asarray(atoms)
    if a.shape != (c['metrics'],c['G'],c['K']+1) or a.dtype.kind not in 'iu':
        raise ValueError('invalid cumulative atom tensor')
    if np.any(a<0) or np.any(a>c['value_bound']*c['horizon']) or np.any(a[:,:,0]):
        raise ValueError('cumulative atom outside declared nonnegative bounded history')
    return a.astype(np.int64,copy=False)


def encode(plan, atoms):
    a=check_atoms(plan,atoms); c=plan['contract']; z=plan['compiled']; kind=plan['decoder']['kind']
    if kind=='RawRankMarginals': return a[:,:,1:].reshape(c['metrics'],-1).copy()
    if kind=='PrunedRankMarginals':
        columns=[]
        if z['mandatory_count']:
            columns.append(sum((a[:,g,1:m+1].sum(axis=1,dtype=np.int64) for g,m in enumerate(z['m'])),np.zeros(c['metrics'],dtype=np.int64)))
        columns.extend(a[:,g,r] for g,r in z['vertices'])
        return np.column_stack(columns).astype(np.int64)
    prefix=np.cumsum(a,axis=2,dtype=np.int64)
    if kind=='AllPolicyMaterialise':
        policies=list(compositions(c['G'],c['K'],c['lo'],c['hi']))
        return np.column_stack([sum((prefix[:,g,q[g]] for g in range(c['G'])),np.zeros(c['metrics'],dtype=np.int64)) for q in policies])
    columns=[sum((prefix[:,g,q] for g,q in enumerate(z['q0'])),np.zeros(c['metrics'],dtype=np.int64))]
    for e in z['oriented_edges']:
        cg,cr=e['child']; pg,pr=e['parent']; columns.append(a[:,cg,cr]-a[:,pg,pr])
    return np.column_stack(columns).astype(np.int64)


def prepare_query_runtime(plan):
    c=plan['contract']; d=plan['decoder']; z=plan['compiled']
    runtime={'plan':plan}
    if d['kind']=='AllPolicyMaterialise':
        runtime['index']={q:i for i,q in enumerate(compositions(c['G'],c['K'],c['lo'],c['hi']))}
    if d['kind']=='PrunedRankMarginals':
        runtime['coords']=([None] if z['mandatory_count'] else [])+[tuple(x) for x in z['vertices']]
    return runtime


def decode_batch(runtime, values, queries):
    plan=runtime['plan']; c=plan['contract']; d=plan['decoder']; kind=d['kind']
    qs=[check_policy(c,q) for q in queries]
    if np.asarray(values).shape != (c['metrics'],d['dimension']): raise ValueError('state shape')
    if not qs: return np.empty((0,c['metrics']),dtype=np.int64)
    if kind=='AllPolicyMaterialise': return values[:,[runtime['index'][q] for q in qs]].T.copy()
    if kind=='RetainQForest':
        # Python integers avoid intermediate cancellation overflow at the certified horizon.
        out=[]
        for q in qs:
            coeff=decoder_coefficients(d,q)
            out.append([sum(int(values[m,b])*int(v) for b,v in coeff.items()) for m in range(c['metrics'])])
        return np.array(out,dtype=np.int64)
    if kind=='RawRankMarginals':
        weights=np.asarray([[int(r<=q[g]) for g in range(c['G']) for r in range(1,c['K']+1)] for q in qs],dtype=np.int64)
    else:
        weights=np.asarray([[1 if x is None else int(x[1]<=q[x[0]]) for x in runtime['coords']] for q in qs],dtype=np.int64)
    # Nonnegative selection sums are bounded by K*B*T, checked at input.
    return weights @ values.T


def bundle_write(destination, plan, values, storage='binary'):
    destination=Path(destination)
    if destination.exists(): raise FileExistsError(destination)
    destination.mkdir(parents=True)
    c=plan['contract']; d=plan['decoder']; z=plan['compiled']
    a=np.asarray(values,dtype='<i8')
    if a.shape != (c['metrics'],d['dimension']): raise ValueError('state shape mismatch')
    if storage=='binary':
        state=destination/'retained_state.bin'; state.write_bytes(a.tobytes(order='C'))
    elif storage=='duckdb':
        state=destination/'retained_state.duckdb'
        con=duckdb.connect(str(state)); con.execute(f'SET threads={THREADS}')
        frame=pd.DataFrame({'metric_id':np.repeat(np.arange(c['metrics'],dtype=np.int32),d['dimension']),
                            'basis_id':np.tile(np.arange(d['dimension'],dtype=np.int32),c['metrics']),
                            'value':a.reshape(-1)})
        con.register('payload',frame)
        con.execute('CREATE TABLE retained_state AS SELECT metric_id::INTEGER AS metric_id,basis_id::INTEGER AS basis_id,value::BIGINT AS value FROM payload ORDER BY metric_id,basis_id')
        con.execute('CHECKPOINT'); con.close()
    else: raise ValueError('unsupported storage format')
    write_json(destination/'contract.json',c); write_json(destination/'decoder.json',d)
    certificate={'schema_version':1,'implementation_version':VERSION,'storage':storage,
                 'counter_dimension_per_metric':d['dimension'],'minimum_linear_rank':z['rank'],
                 'contract_sha256':sha256_file(destination/'contract.json'),
                 'decoder_sha256':sha256_file(destination/'decoder.json'),
                 'state_sha256':sha256_file(state),'state_file':state.name,
                 'metric_count':c['metrics'],'source_provenance_proved':False}
    write_json(destination/'certificate.json',certificate)
    return destination


def bundle_load(bundle):
    bundle=Path(bundle); c=read_json(bundle/'contract.json'); d=read_json(bundle/'decoder.json'); cert=read_json(bundle/'certificate.json')
    if cert['storage']=='binary': a=np.fromfile(bundle/cert['state_file'],dtype='<i8').reshape(c['metrics'],d['dimension'])
    else:
        con=duckdb.connect(str(bundle/cert['state_file']),read_only=True)
        a=np.array(con.execute('SELECT value FROM retained_state ORDER BY metric_id,basis_id').fetchall(),dtype=np.int64).reshape(c['metrics'],d['dimension']); con.close()
    low=[max(l,c['K']-sum(c['hi'])+u) for l,u in zip(c['lo'],c['hi'])]
    high=[min(u,c['K']-sum(c['lo'])+l) for l,u in zip(c['lo'],c['hi'])]
    compiled={'m':low,'M':high,'mandatory_count':sum(low),
              'vertices':[(g,r) for g in range(c['G']) for r in range(low[g]+1,high[g]+1)]}
    return prepare_query_runtime({'contract':c,'decoder':d,'compiled':compiled}), a


def fresh_verify(verifier_path,bundle,queries,work):
    work=Path(work); work.mkdir(parents=True,exist_ok=True)
    query_path=work/'queries.json'; output=work/'verified.json'; write_json(query_path,[list(q) for q in queries])
    proc=subprocess.run([sys.executable,str(verifier_path),'--bundle',str(bundle),'--queries',str(query_path),'--output',str(output)],capture_output=True,text=True,timeout=180)
    if proc.returncode: raise AssertionError('fresh verifier failed: '+(proc.stderr or proc.stdout)[-4000:])
    return read_json(output)


def archive_sizes(bundle,plan):
    b=Path(bundle); cert=read_json(b/'certificate.json'); payload=plan['contract']['metrics']*plan['decoder']['dimension']*8
    sizes={p.name:p.stat().st_size for p in b.iterdir()}
    return {'value_payload_bytes':payload,'state_file_bytes':sizes[cert['state_file']],
            'metadata_bytes':sum(v for k,v in sizes.items() if k!=cert['state_file']),
            'total_bundle_bytes':sum(sizes.values()),'state_sha256':cert['state_sha256'],
            'bundle_content_sha256':digest_value({p.name:sha256_file(p) for p in sorted(b.iterdir())})}


def oracle_raw(rows,queries,G,K,metrics):
    # Independent oracle: raw tuples, Python grouping/sorting/slicing; no compiler, atomizer,
    # encoder, response-row, or decoder helper is called here.
    groups={}
    for row in rows:
        groups.setdefault((row['round_id'],row['group_id']),[]).append(row)
    ordered={key:sorted(items,key=lambda r:(-int(r['score']),int(r['candidate_id']))) for key,items in groups.items()}
    answers=[]
    for q in queries:
        total=[0]*metrics
        for (round_id,group),items in ordered.items():
            for row in items[:q[group]]:
                for m in range(metrics): total[m]+=int(row[f'metric_{m}'])
        answers.append(total)
    return np.asarray(answers,dtype=np.int64).reshape(len(queries),metrics)


def connection():
    con=duckdb.connect(':memory:'); con.execute(f'SET threads={THREADS}'); con.execute("SET memory_limit='4GB'")
    return con


def atomize_rows(rows,c):
    con=connection(); cols=['round_id','group_id','candidate_id','score']+[f'metric_{m}' for m in range(c['metrics'])]
    frame=pd.DataFrame(rows,columns=cols)
    for col in cols: frame[col]=frame[col].astype('int64')
    con.register('incoming',frame)
    fields=','.join(f'SUM(metric_{m})::BIGINT AS metric_{m}' for m in range(c['metrics']))
    output=con.execute(f'''WITH ranked AS (SELECT *,row_number() OVER(PARTITION BY round_id,group_id ORDER BY score DESC,candidate_id ASC) AS r FROM incoming)
                         SELECT group_id,r,{fields} FROM ranked WHERE r<={c['K']} GROUP BY group_id,r''').fetchall()
    con.close(); a=np.zeros((c['metrics'],c['G'],c['K']+1),dtype=np.int64)
    for g,r,*vals in output: a[:,int(g),int(r)]=vals
    return a


def generic_answers(atoms,queries):
    # Direct workload definition, separate from basis construction.
    out=[]
    for q in queries:
        out.append([sum(int(atoms[m,g,r]) for g,quota in enumerate(q) for r in range(1,quota+1)) for m in range(atoms.shape[0])])
    return np.asarray(out,dtype=np.int64).reshape(len(queries),atoms.shape[0])


def canonical_rounds(rows,sealed_ids,c):
    sealed_ids=list(sealed_ids)
    if any(type(x) is not int or x<0 for x in sealed_ids) or len(set(sealed_ids))!=len(sealed_ids):
        raise ValueError('sealed round ids must be unique nonnegative integers')
    groups={i:[] for i in sealed_ids}; seen=set()
    wanted={'round_id','group_id','candidate_id','score'}|{f'metric_{i}' for i in range(c['metrics'])}
    for row in rows:
        if type(row) is not dict or set(row)!=wanted or any(type(v) is not int for v in row.values()):
            raise ValueError('raw row schema/integer type mismatch')
        t,g,key=row['round_id'],row['group_id'],row['candidate_id']
        if t not in groups or not 0<=g<c['G'] or key<0 or abs(row['score'])>INT64_MAX:
            raise ValueError('invalid round, group, key or score')
        identity=(t,g,key)
        if identity in seen: raise ValueError('duplicate candidate key within round/group')
        seen.add(identity)
        if any(not 0<=row[f'metric_{m}']<=c['value_bound'] for m in range(c['metrics'])):
            raise ValueError('metric outside certified nonnegative per-tuple bound')
        groups[t].append(row)
    return {t:sorted(items,key=lambda r:(r['group_id'],r['candidate_id'])) for t,items in groups.items()}


class SealedRoundCapture:
    '''Trusted complete-round API. Identical replay is ignored; conflicting replay is rejected.
    It does not infer whether upstream data is complete and does not implement late updates.'''
    def __init__(self,path,compiled):
        self.path=Path(path); self.compiled=compiled; self.c=compiled['contract']; self.path.parent.mkdir(parents=True,exist_ok=True)
        self.con=duckdb.connect(str(path)); self.con.execute(f'SET threads={THREADS}')
        self.con.execute('CREATE TABLE IF NOT EXISTS contract_digest(value VARCHAR)')
        dig=digest_value(self.c); existing=self.con.execute('SELECT value FROM contract_digest').fetchall()
        if existing and existing!=[(dig,)]: raise ValueError('capture database contract mismatch')
        if not existing: self.con.execute('INSERT INTO contract_digest VALUES (?)',[dig])
        self.con.execute('CREATE TABLE IF NOT EXISTS retained_state(metric_id INTEGER,basis_id INTEGER,value BIGINT,PRIMARY KEY(metric_id,basis_id))')
        self.con.execute(f'''INSERT INTO retained_state SELECT m,b,0::BIGINT FROM range({self.c['metrics']}) x(m),range({compiled['rank']}) y(b) ON CONFLICT DO NOTHING''')
        self.con.execute('CREATE TABLE IF NOT EXISTS round_ledger(round_id BIGINT PRIMARY KEY,payload_sha256 VARCHAR,candidate_count BIGINT)')
        terms=pd.DataFrame(compiled['basis_terms']).rename(columns={'group':'group_id','rank':'rank_position'})
        self.con.register('terms_frame',terms)
        self.con.execute('CREATE OR REPLACE TEMP TABLE basis_terms AS SELECT * FROM terms_frame')

    def apply(self,rows,sealed_ids,fault=None):
        rounds=canonical_rounds(rows,sealed_ids,self.c)
        existing={int(t):h for t,h in self.con.execute('SELECT round_id,payload_sha256 FROM round_ledger').fetchall()}
        hashes={t:digest_value(items) for t,items in rounds.items()}
        for t in rounds:
            if t in existing and existing[t]!=hashes[t]: raise ValueError('conflicting delivery of already sealed round')
        new=[t for t in rounds if t not in existing]
        if len(existing)+len(new)>self.c['horizon']: raise OverflowError('observed round count exceeds declared horizon')
        if not new: return {'new_rounds':0,'new_rows':0}
        data=[row for t in new for row in rounds[t]]
        columns=['round_id','group_id','candidate_id','score']+[f'metric_{m}' for m in range(self.c['metrics'])]
        frame=pd.DataFrame(data,columns=columns)
        for col in columns: frame[col]=frame[col].astype('int64')
        self.con.register('raw_batch',frame)
        ledger=pd.DataFrame([(t,hashes[t],len(rounds[t])) for t in new],columns=['round_id','payload_sha256','candidate_count'])
        self.con.register('ledger_batch',ledger)
        atom_parts=[f'SELECT group_id,rank_position,{m}::INTEGER AS metric_id,SUM(metric_{m})::HUGEINT AS atom_value FROM ranked_batch GROUP BY group_id,rank_position' for m in range(self.c['metrics'])]
        self.con.execute('BEGIN TRANSACTION')
        try:
            self.con.execute(f'''CREATE OR REPLACE TEMP TABLE ranked_batch AS SELECT *,row_number() OVER(PARTITION BY round_id,group_id ORDER BY score DESC,candidate_id ASC) AS rank_position FROM raw_batch QUALIFY rank_position<={self.c['K']}''')
            self.con.execute(f'''WITH atoms AS ({' UNION ALL '.join(atom_parts)}),updates AS (
                SELECT metric_id,basis_id,SUM(atom_value*coefficient)::BIGINT AS delta FROM atoms JOIN basis_terms USING(group_id,rank_position) GROUP BY metric_id,basis_id)
                UPDATE retained_state s SET value=s.value+u.delta FROM updates u WHERE s.metric_id=u.metric_id AND s.basis_id=u.basis_id''')
            if fault=='before_commit': os._exit(91)
            self.con.execute('INSERT INTO round_ledger SELECT * FROM ledger_batch')
            self.con.execute('COMMIT')
            if fault=='after_commit': os._exit(92)
        except BaseException:
            self.con.execute('ROLLBACK'); raise
        finally:
            self.con.unregister('raw_batch'); self.con.unregister('ledger_batch')
        return {'new_rounds':len(new),'new_rows':len(data)}

    def values(self):
        rows=self.con.execute('SELECT value FROM retained_state ORDER BY metric_id,basis_id').fetchall()
        return np.asarray(rows,dtype=np.int64).reshape(self.c['metrics'],self.compiled['rank'])

    def close(self): self.con.close()


def publish_capture(capture,destination,verifier,work,fault=None):
    destination=Path(destination)
    if destination.exists(): raise FileExistsError('published archives are immutable')
    stage=destination.with_name(destination.name+'.staging')
    if stage.exists(): shutil.rmtree(stage)
    plan=make_plan(capture.compiled,'RetainQForest')
    bundle_write(stage,plan,capture.values(),'binary')
    fresh_verify(verifier,stage,[],work)
    if fault=='before_publish': os._exit(93)
    os.replace(stage,destination)
    return destination


def random_rows(seed,rounds,G,metrics,B,max_candidates=10):
    rng=random.Random(seed); rows=[]; cid=0
    for t in range(rounds):
        for g in range(G):
            for _ in range(rng.randrange(max_candidates+1)):
                rows.append({'round_id':t,'group_id':g,'candidate_id':cid,'score':rng.randrange(4),
                             **{f'metric_{m}':rng.randrange(B+1) for m in range(metrics)}}); cid+=1
    rng.shuffle(rows); return rows


def save_table(path,rows):
    frame=pd.DataFrame(rows); Path(path).parent.mkdir(parents=True,exist_ok=True); frame.to_csv(path,index=False); return frame


def worker_main():
    parser=argparse.ArgumentParser(); parser.add_argument('--worker',choices=['capture_fault','publish_fault','benchmark']); parser.add_argument('--config')
    args=parser.parse_args(); cfg=read_json(args.config)
    if args.worker=='benchmark':
        context={k:(Path(v) if k in {'root','run','verifier','core'} else v) for k,v in cfg['context'].items()}
        result=benchmark_repetition(context,cfg['case'],cfg['rep'])
        write_json(cfg['output'],result); return
    z=compile_contract(cfg['contract'])
    capture=SealedRoundCapture(cfg['database'],z)
    if args.worker=='capture_fault': capture.apply(cfg['rows'],cfg['sealed_ids'],cfg['fault'])
    else: publish_capture(capture,cfg['destination'],cfg['verifier'],cfg['work'],cfg['fault'])
    capture.close()


def configure_run(root, mode='CONFIRMATORY', include_real=True, seed=20261018):
    global THREADS
    if mode not in {'SMOKE','CONFIRMATORY'}: raise ValueError('MODE')
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'_'+mode
    run=root/'runs'/stamp
    if run.exists(): run=run.with_name(run.name+'_'+str(os.getpid()))
    for name in ['tables','manifests','code','bundles','figures','checks','temp']:
        (run/name).mkdir(parents=True,exist_ok=True)
    THREADS=min(2,os.cpu_count() or 1)
    config={'mode':mode,'seed':seed,'threads':THREADS,'repetitions':1 if mode=='SMOKE' else 5,
            'oracle_cases':24 if mode=='SMOKE' else 400,'include_real':bool(include_real),
            'all_policy_cap':10000,'synthetic_rows':30000 if mode=='SMOKE' else 2000000,
            'widths':[1,2,16,256] if mode=='SMOKE' else [1,2,4,16,64,256,1024],
            'query_repeats':3 if mode=='SMOKE' else 15,
            'interpretation':'Corrective focused experiment suite; synthetic contract probes are not deployment prevalence evidence.'}
    write_json(run/'manifests/configuration.json',config)
    versions={m:__import__(m).__version__ for m in ['duckdb','numpy','pandas','pyarrow','psutil']}
    environment={'python':sys.version,'platform':platform.platform(),'cpu_count':os.cpu_count(),
                 'ram_bytes':psutil.virtual_memory().total,'gpu_required':False,'versions':versions}
    write_json(run/'manifests/environment.json',environment)
    for filename in ['retainq_v6.py','retainq_verifier.py']:
        source=Path(__file__).parent/filename
        shutil.copy2(source,run/'code'/filename)
    write_json(run/'manifests/source_sha256.json',{p.name:sha256_file(p) for p in (run/'code').iterdir()})
    return {'root':root,'run':run,'config':config,'verifier':run/'code/retainq_verifier.py','core':run/'code/retainq_v6.py'}


def stage(context,name,function):
    began=time.perf_counter(); print(f'[{name}] started',flush=True)
    try:
        value=function()
        write_json(context['run']/f'checks/{name}_status.json',{'status':'passed','elapsed_seconds':time.perf_counter()-began})
        print(f'[{name}] complete in {time.perf_counter()-began:.1f}s',flush=True)
        return value
    except BaseException as error:
        write_json(context['run']/f'checks/{name}_status.json',{'status':'failed','error':repr(error),'traceback':traceback.format_exc(),'elapsed_seconds':time.perf_counter()-began})
        export_results(context,allow_incomplete=True)
        raise


def validation_suite(context):
    cfg=context['config']; run=context['run']; rng=random.Random(cfg['seed']); records=[]
    for index in range(cfg['oracle_cases']):
        G=rng.randint(1,4); K=rng.randint(1,5); metrics=2; T=rng.randint(1,5); B=20
        base=[0]*G
        for _ in range(K): base[rng.randrange(G)]+=1
        lo=[rng.randint(0,x) for x in base]; hi=[rng.randint(x,K) for x in base]
        if index%6==0: lo=base[:]; hi=base[:]
        if index%6==1: G=2; lo=[0,0]; hi=[K,K]
        raw={'G':G,'K':K,'lo':lo,'hi':hi,'metrics':metrics,'value_bound':B,'horizon':T}
        z=compile_contract(raw); c=z['contract']; rows=random_rows(cfg['seed']+index,T,G,metrics,B,7)
        # Independent brute-force policy enumeration at deliberately small G,K.
        qs=[q for q in itertools.product(range(K+1),repeat=G) if sum(q)==K and all(l<=x<=h for x,l,h in zip(q,lo,hi))]
        expected=oracle_raw(rows,qs,G,K,metrics); a=atomize_rows(rows,c)
        matrix=[[int(r<=q[g]) for g in range(G) for r in range(1,K+1)] for q in qs]
        rank=exact_rank(matrix)
        if rank!=z['rank']: raise AssertionError('rational response rank mismatch')
        for kind in KINDS:
            plan=make_plan(z,kind); state=encode(plan,a); observed=decode_batch(prepare_query_runtime(plan),state,qs)
            if not np.array_equal(expected,observed): raise AssertionError(('raw oracle mismatch',index,kind))
        records.append({'case':index,'G':G,'K':K,'rounds':T,'rows':len(rows),'policies':len(qs),'rank':rank,
                        'raw_oracle_queries':len(qs),'effective_variable_groups':z['effective_variable_groups'],'mismatches':0})
    frame=save_table(run/'tables/raw_oracle_cases.csv',records)
    base={'G':2,'K':2,'lo':[0,0],'hi':[2,2],'metrics':1,'value_bound':10,'horizon':2}
    bads=[('fractional capacity',{'K':2.9}),('boolean capacity',{'K':True}),('round resolved',{'granularity':'round-resolved'}),
          ('floating arithmetic',{'arithmetic':'float'}),('128 bit words',{'word_bits':128}),('16 bit words',{'word_bits':16}),
          ('unknown field',{'capacity_schedule':[1,2]}),('bad lower bounds',{'lo':[-1,0]}),('infeasible',{'lo':[2,2]}),
          ('negative bound',{'value_bound':-1}),('overflow horizon',{'horizon':2**63}),('wrong metric schema',{'metrics':1.5})]
    denied=[]
    for name,patch in bads:
        try: compile_contract({**base,**patch})
        except (ValueError,OverflowError): denied.append({'test':name,'rejected':True})
        else: raise AssertionError('invalid contract accepted: '+name)
    save_table(run/'tables/contract_rejections.csv',denied)
    # Cancellation-sensitive exactness near the certified horizon.
    huge=compile_contract({**base,'value_bound':1,'horizon':(2**63-1)//2})
    a=np.zeros((1,2,3),dtype=np.int64); a[0,0,1:]=[huge['contract']['horizon'],1]; a[0,1,1:]=[3,huge['contract']['horizon']-4]
    qs=[(0,2),(1,1),(2,0)]; expected=generic_answers(a,qs)
    for kind in KINDS:
        plan=make_plan(huge,kind)
        if not np.array_equal(decode_batch(prepare_query_runtime(plan),encode(plan,a),qs),expected): raise AssertionError('boundary arithmetic')
    checks=[]; z=compile_contract(base); rows=random_rows(12,2,2,1,10,4); atoms=atomize_rows(rows,z['contract']); qs=[(0,2),(1,1),(2,0)]
    expected=oracle_raw(rows,qs,2,2,1).tolist()
    for kind in KINDS:
        plan=make_plan(z,kind)
        for storage in FORMATS:
            b=run/'checks'/f'valid_{kind}_{storage}'; bundle_write(b,plan,encode(plan,atoms),storage)
            result=fresh_verify(context['verifier'],b,qs,run/'temp/verifier_validation')
            if result['answers']!=expected: raise AssertionError('standalone oracle mismatch')
            checks.append({'kind':kind,'storage':storage,'external_answers_match':True})
    save_table(run/'tables/bundle_verification_checks.csv',checks)
    # Rehash-aware mutation: source truth is not asserted, only definite schema/structure/bounds errors.
    original=run/'checks/valid_RetainQForest_binary'; mutations=[]
    for name in ['extra_file','answer_fixture','state_bound','wrong_dimension','out_of_contract_query']:
        target=run/'temp'/('mutant_'+name)
        if target.exists(): shutil.rmtree(target)
        shutil.copytree(original,target); queries=qs
        if name=='extra_file': (target/'expected_answers.json').write_text('[]')
        elif name=='answer_fixture':
            c=read_json(target/'contract.json'); c['expected_answers']=expected; write_json(target/'contract.json',c)
        elif name=='state_bound':
            v=np.fromfile(target/'retained_state.bin',dtype='<i8'); v[1]=100000; (target/'retained_state.bin').write_bytes(v.tobytes())
        elif name=='wrong_dimension':
            d=read_json(target/'decoder.json'); d['dimension']+=1; write_json(target/'decoder.json',d)
        else: queries=[(3,-1)]
        cert=read_json(target/'certificate.json')
        for f,k in [('contract.json','contract_sha256'),('decoder.json','decoder_sha256'),('retained_state.bin','state_sha256')]: cert[k]=sha256_file(target/f)
        write_json(target/'certificate.json',cert)
        try: fresh_verify(context['verifier'],target,queries,run/'temp/verifier_mutation')
        except AssertionError: mutations.append({'mutation':name,'rejected':True})
        else: raise AssertionError('invalid archive/query accepted '+name)
    save_table(run/'tables/mutation_checks.csv',mutations)
    return {'raw_oracle_cases':len(records),'raw_oracle_queries':int(frame.raw_oracle_queries.sum()),'contract_rejections':len(denied),'archive_checks':len(checks),'mutations':len(mutations)}


def closed_form_rank(c):
    total_lo,total_hi=sum(c['lo']),sum(c['hi'])
    widths=[min(u,c['K']-total_lo+l)-max(l,c['K']-total_hi+u) for l,u in zip(c['lo'],c['hi'])]
    active=sum(w>0 for w in widths)
    return 1 if not active else (max(widths)+1 if active==2 else sum(widths))


def compiler_suite(context):
    cfg=context['config']; rows=[]
    specs=[('binary_small',2,5,[0,0],[5,5]),('binary_50',2,50,[0,0],[50,50]),
           ('C0',8,50,[0]*8,[50]*8),('C5',16,80,[4]*16,[6]*16),
           ('C6',64,300,[4]*62+[0,0],[4]*62+[52,52])]
    if cfg['mode']=='CONFIRMATORY': specs.append(('C2',32,50,[0]*32,[50]*32))
    for label,G,K,lo,hi in specs:
        c=validate_contract({'G':G,'K':K,'lo':lo,'hi':hi,'metrics':1,'value_bound':100,'horizon':50})
        for rep in range(cfg['repetitions']):
            began=time.perf_counter(); z=compile_contract(c); elapsed=time.perf_counter()-began
            began=time.perf_counter()
            for _ in range(1000): rank=closed_form_rank(c)
            simple=(time.perf_counter()-began)/1000
            if rank!=z['rank']: raise AssertionError('closed-form baseline')
            explicit=None
            if z['policy_count']<=128 and G*K<=256:
                began=time.perf_counter(); r=exact_rank([quota_row(q,K) for q in compositions(G,K,lo,hi)]); explicit=time.perf_counter()-began
                if r!=rank: raise AssertionError('explicit compiler rank')
            rows.append({'case':label,'rep':rep,'G':G,'K':K,'policies':str(z['policy_count']),
                         'rank':rank,'pruned':z['pruned_dimension'],'raw':z['raw_dimension'],
                         'effective_variable_groups':z['effective_variable_groups'],'graph_edges':z['edge_count'],
                         'retained_forest_edges':len(z['oriented_edges']),'streamed_compile_seconds':elapsed,
                         'closed_form_rank_seconds':simple,'explicit_rational_rank_seconds':explicit})
        print('  compiler',label,'policies',z['policy_count'],'rank',rank,flush=True)
    save_table(context['run']/'tables/compiler_raw.csv',rows)
    rng=random.Random(cfg['seed']+71); topology=[]
    for i in range(50 if cfg['mode']=='SMOKE' else 1000):
        G=rng.randint(1,6); K=rng.randint(1,12); q=[0]*G
        for _ in range(K): q[rng.randrange(G)]+=1
        lo=[rng.randint(0,x) for x in q]; hi=[rng.randint(x,K) for x in q]
        z=compile_contract({'G':G,'K':K,'lo':lo,'hi':hi,'metrics':1,'value_bound':1,'horizon':1})
        if z['rank']!=closed_form_rank(z['contract']): raise AssertionError('topology formula')
        simple=min(z['pruned_dimension'],z['policy_count'])
        topology.append({'case':i,'G':G,'K':K,'lower':json.dumps(lo),'upper':json.dumps(hi),'policies':str(z['policy_count']),
                         'effective_variable_groups':z['effective_variable_groups'],'rank':z['rank'],'pruned':z['pruned_dimension'],
                         'best_simple_dimension':simple,'extra_counters_saved':simple-z['rank']})
    save_table(context['run']/'tables/topology_contracts.csv',topology)
    return rows


def prepare_data(context,existing_cache=''):
    cfg=context['config']; cache=context['root']/'cache'/cfg['mode']; cache.mkdir(parents=True,exist_ok=True)
    legacy=Path(existing_cache) if existing_cache else None
    result={}
    synth=cache/'synthetic.parquet'
    result['synthetic']=prepare_synthetic(synth,cfg['synthetic_rows'],50 if cfg['mode']=='SMOKE' else 200,64,16)
    if cfg['include_real']:
        acs=cache/'acs.parquet'; ml=cache/'movielens.parquet'
        if legacy and cfg['mode']=='CONFIRMATORY':
            for target,name in [(acs,'acs_2018_ca_v5_compact.parquet'),(ml,'movielens_25m_v5.parquet')]:
                if not target.exists() and (legacy/name).exists(): shutil.copy2(legacy/name,target)
            meta=legacy/'movielens_25m_v5.metadata.json'
            if meta.exists() and not ml.with_suffix('.metadata.json').exists(): shutil.copy2(meta,ml.with_suffix('.metadata.json'))
        result['acs']=prepare_acs(acs,cache/'acs_raw',cfg['mode'])
        result['movielens']=prepare_movielens(ml,cache/'movielens_raw',cfg['mode'])
        # Check full-data status explicitly; never silently substitute the small dataset.
        if cfg['mode']=='CONFIRMATORY' and (result['acs']['rows']<100000 or result['movielens']['rows']!=25000095):
            raise AssertionError('confirmatory real data incomplete')
    write_json(context['run']/'manifests/datasets.json',result)
    return result


def workload_specs(context,datasets):
    cfg=context['config']; full=cfg['mode']=='CONFIRMATORY'; rows=cfg['synthetic_rows']; T=200 if full else 50
    cases=[{'id':'D0','dataset':'synthetic','G':4,'K':20,'lo':[3]*4,'hi':[7]*4,'metrics':4,'value_bound':100,'horizon':T,'rows':min(rows,1000000),'group_column':'group_base'},
           {'id':'D3','dataset':'synthetic','G':2,'K':20,'lo':[0,0],'hi':[20,20],'metrics':4,'value_bound':100,'horizon':T,'rows':min(rows,1000000),'group_column':'group_base'},
           {'id':'D9','dataset':'synthetic','G':64,'K':300,'lo':[4]*62+[0,0],'hi':[4]*62+[52,52],'metrics':16,'value_bound':100,'horizon':50,'rows':rows,'group_column':'group_base'}]
    if 'acs' in datasets:
        T=50 if full else 10; n=datasets['acs']['rows']
        for label,G,lo,hi,group in [('A0',4,[3]*4,[7]*4,'group_base'),('A1',2,[0,0],[20,20],'group_binary')]:
            cases.append({'id':label,'dataset':'acs','G':G,'K':20,'lo':lo,'hi':hi,'metrics':2,'value_bound':200,'horizon':T,'rows':n,'group_column':group})
    if 'movielens' in datasets:
        T=datasets['movielens']['rounds']; n=datasets['movielens']['rows']
        for label,G,lo,hi,group in [('M0',5,[0]*5,[4]*5,'group_base'),('M1',2,[0,0],[10,10],'group_binary')]:
            cases.append({'id':label,'dataset':'movielens','G':G,'K':10,'lo':lo,'hi':hi,'metrics':2,'value_bound':200,'horizon':T,'rows':n,'group_column':group})
    for case in cases:
        case['data_path']=datasets[case['dataset']]['path']
        c={k:case[k] for k in ['G','K','lo','hi','metrics','value_bound','horizon']}
        names=[f'deterministic synthetic integer metric {i}' for i in range(case['metrics'])]
        grouping=f'{case["group_column"]} modulo {case["G"]}'
        if case['dataset']=='acs':
            names=['employment indicator ESR=1','clipped nonnegative income divided by 1000']
            grouping='recorded SEX codes 1/2 mapped to 0/1' if case['id']=='A1' else 'occupation code buckets min(OCCP//2500,3)'
        if case['dataset']=='movielens':
            names=['twice recorded rating','release year minus 1900 clipped to [0,200]']
            grouping='release before 2000 versus 2000 onward' if case['id']=='M1' else 'five release-era buckets'
        c['semantics']={'ranking':'score DESC, candidate_id ASC','grouping':grouping,'observables':names,
                        'rounds':'complete immutable sealed rounds','missing_positions':'zero; shortfall is not redistributed'}
        case['contract']=validate_contract(c)
    write_json(context['run']/'manifests/workloads.json',cases)
    return cases


def materialize_atoms(case,sample_rounds=8):
    c=case['contract']; con=connection(); fields=','.join(f'metric_{m}' for m in range(c['metrics']))
    start=time.perf_counter()
    con.execute(f'''CREATE TEMP TABLE source AS SELECT round_id%{c['horizon']} AS round_id,{case['group_column']}%{c['G']} AS group_id,
                    candidate_id,score,{fields} FROM read_parquet(?) WHERE row_id<{case['rows']}''',[case['data_path']])
    input_seconds=time.perf_counter()-start
    start=time.perf_counter()
    con.execute(f'''CREATE TEMP TABLE ranked AS SELECT *,row_number() OVER(PARTITION BY round_id,group_id ORDER BY score DESC,candidate_id ASC) AS r FROM source QUALIFY r<={c['K']}''')
    sums=','.join(f'SUM(metric_{m})::BIGINT' for m in range(c['metrics']))
    records=con.execute(f'SELECT group_id,r,{sums} FROM ranked GROUP BY group_id,r ORDER BY group_id,r').fetchall()
    common_seconds=time.perf_counter()-start
    atoms=np.zeros((c['metrics'],c['G'],c['K']+1),dtype=np.int64)
    for g,r,*vals in records: atoms[:,int(g),int(r)]=vals
    # Complete selected rounds, not a truncated tuple sample.
    sample=con.execute(f'''SELECT * FROM source WHERE round_id IN (SELECT DISTINCT round_id FROM source ORDER BY round_id LIMIT {sample_rounds})''').fetchdf()
    sample_rows=[{k:int(v) for k,v in row.items()} for row in sample.to_dict('records')]
    coverage=con.execute(f'''WITH counts AS(SELECT round_id,group_id,count(*) n FROM source GROUP BY round_id,group_id),r AS(
                       SELECT round_id,count(*) g,min(n) min_n FROM counts GROUP BY round_id)
                       SELECT count(*),sum(CASE WHEN g={c['G']} THEN 1 ELSE 0 END),sum(CASE WHEN g={c['G']} AND min_n>={c['K']} THEN 1 ELSE 0 END) FROM r''').fetchone()
    con.close()
    return atoms,sample_rows,{'input_load_seconds':input_seconds,'common_rank_atomize_seconds':common_seconds,
                             'observed_rounds':int(coverage[0] or 0),'rounds_all_groups':int(coverage[1] or 0),
                             'rounds_all_groups_at_least_K':int(coverage[2] or 0)}


def benchmark_repetition(context,case,rep):
    cfg=context['config']; run=context['run']; z=compile_contract(case['contract']); c=z['contract']
    atoms,sample,common=materialize_atoms(case,3 if cfg['mode']=='SMOKE' else 8)
    qs=list(compositions(c['G'],c['K'],c['lo'],c['hi']))
    if len(qs)>cfg['all_policy_cap']: raise ValueError('focused benchmark explicit cap')
    random.Random(cfg['seed']+rep).shuffle(qs)
    expected=generic_answers(atoms,qs)
    if rep==0:
        # Independent Python oracle over complete sampled source rounds.
        sample_atoms=atomize_rows(sample,c); raw_expected=oracle_raw(sample,qs,c['G'],c['K'],c['metrics'])
        for kind in KINDS:
            plan=make_plan(z,kind)
            if not np.array_equal(decode_batch(prepare_query_runtime(plan),encode(plan,sample_atoms),qs),raw_expected):
                raise AssertionError('real/synthetic sample raw-tuple oracle '+case['id'])
        write_json(run/f'checks/{case["id"]}_independent_source_oracle.json',
                   {'complete_sample_rounds':len({r['round_id'] for r in sample}),'raw_rows':len(sample),
                    'policies':len(qs),'metrics':c['metrics'],'answers_sha256':digest_value(raw_expected.tolist()),
                    'scope':'complete sampled source rounds, not a claim of independent Python replay of every full-data row'})
        write_json(run/f'checks/{case["id"]}_external_full_atom_reference.json',{'queries':qs,'expected_answers':expected.tolist(),
                    'scope':'direct workload definition on shared full-data atoms; fixtures are outside all retained bundles'})
    methods=KINDS[:]; random.Random(cfg['seed']+rep*97+len(case['id'])).shuffle(methods)
    measurements=[]
    for method_order,kind in enumerate(methods):
        plan=make_plan(z,kind,cfg['all_policy_cap'])
        # Untimed warm-up; no correctness or duplicate-delivery work in encoding timer.
        encode(plan,atoms)
        began=time.perf_counter(); values=encode(plan,atoms); encode_seconds=time.perf_counter()-began
        runtime=prepare_query_runtime(plan)
        if not np.array_equal(decode_batch(runtime,values,qs),expected): raise AssertionError('full atom reference mismatch')
        formats=FORMATS[:]; random.Random(cfg['seed']+rep+method_order).shuffle(formats)
        for storage in formats:
            b=run/'bundles'/f'{case["id"]}_{kind}_{storage}_rep{rep}'
            began=time.perf_counter(); bundle_write(b,plan,values,storage); finalize_seconds=time.perf_counter()-began
            began=time.perf_counter(); verified=fresh_verify(context['verifier'],b,qs,run/f'temp/verify_{os.getpid()}'); verify_seconds=time.perf_counter()-began
            if verified['answers']!=expected.tolist(): raise AssertionError('fresh full-data decoder mismatch')
            began=time.perf_counter(); loaded,stored=bundle_load(b); load_seconds=time.perf_counter()-began
            if not np.array_equal(stored,values): raise AssertionError('serialization mismatch')
            decode_batch(loaded,stored,qs)
            one_times=[]; batch_times=[]; qone=[qs[len(qs)//2]]
            for _ in range(cfg['query_repeats']):
                began=time.perf_counter(); observed=decode_batch(loaded,stored,qone); one_times.append(time.perf_counter()-began)
                began=time.perf_counter(); batch=decode_batch(loaded,stored,qs); batch_times.append(time.perf_counter()-began)
            if not np.array_equal(batch,expected): raise AssertionError('warm decoder mismatch')
            result={'case':case['id'],'dataset':case['dataset'],'representation':kind,'storage':storage,'rep':rep,
                    'method_order':method_order,'metrics':c['metrics'],'policies':len(qs),'rank':z['rank'],
                    'dimension_per_metric':plan['decoder']['dimension'],'counter_count':int(values.size),
                    'encode_seconds':encode_seconds,'finalize_seconds':finalize_seconds,
                    'fresh_verify_process_seconds':verify_seconds,'verifier_internal_seconds':verified['elapsed_seconds'],
                    'state_load_and_query_setup_seconds':load_seconds,'warm_single_query_seconds':statistics.median(one_times),
                    'warm_all_policy_batch_seconds':statistics.median(batch_times),'fresh_worker_process':True,
                    'source_excluded_from_bundle':True,'mismatches':0,**archive_sizes(b,plan),**common}
            measurements.append(result)
            if rep!=0: shutil.rmtree(b)
    return {'measurements':measurements,'common':common,'worker_pid':os.getpid()}


def benchmark_suite(context,cases):
    cfg=context['config']; run=context['run']; records=[]; schedule=[]
    for rep in range(cfg['repetitions']):
        order=list(cases); random.Random(cfg['seed']+rep*101).shuffle(order)
        for slot,case in enumerate(order):
            payload={'context':{k:str(v) if isinstance(v,Path) else v for k,v in context.items()},'case':case,'rep':rep,
                     'output':str(run/f'temp/bench_{case["id"]}_{rep}.json')}
            config_path=run/f'temp/bench_{case["id"]}_{rep}_config.json'; write_json(config_path,payload)
            began=time.perf_counter()
            proc=subprocess.run([sys.executable,str(context['core']),'--worker','benchmark','--config',str(config_path)],
                                capture_output=True,text=True,timeout=1800)
            if proc.returncode: raise AssertionError(f'benchmark worker {case["id"]}: '+(proc.stderr or proc.stdout)[-6000:])
            output=read_json(payload['output']); records.extend(output['measurements'])
            schedule.append({'rep':rep,'slot':slot,'case':case['id'],'worker_pid':output['worker_pid'],'wall_seconds':time.perf_counter()-began})
            save_table(run/'tables/benchmark_raw.csv',records); save_table(run/'tables/benchmark_schedule.csv',schedule)
            print(f'  {case["id"]} rep {rep+1}/{cfg["repetitions"]}: {time.perf_counter()-began:.1f}s',flush=True)
    return pd.DataFrame(records)


def width_suite(context,cases):
    cfg=context['config']; run=context['run']; records=[]
    targets=[c for c in cases if c['id'] in {'A1','M1','D9'}]
    for case in targets:
        original=case['contract']; maximum=max(cfg['widths']); rng=np.random.default_rng(cfg['seed']+sum(map(ord,case['id'])))
        # Every aggregate is in [0,B*T] and can be explicitly distributed over T rounds
        # with per-round values in [0,B]. Fixed ranks can be realized by descending scores.
        # These are independent synthetic observables, not ACS/MovieLens measured columns.
        all_atoms=rng.integers(0,original['value_bound']*original['horizon']+1,
                              size=(maximum,original['G'],original['K']+1),dtype=np.int64)
        all_atoms[:,:,0]=0
        for width in cfg['widths']:
            c=dict(original); c['metrics']=width; c['semantics']=dict(original['semantics'])
            c['semantics']['observables']=[f'synthetic bounded-history observable {i}; not a measured real-data column' for i in range(width)]
            z=compile_contract(c); atoms=all_atoms[:width]; qs=list(compositions(c['G'],c['K'],c['lo'],c['hi']))
            expected=generic_answers(atoms,qs)
            kinds=KINDS if width<=2 else [x for x in KINDS if x!='RawRankMarginals']
            for kind in kinds:
                plan=make_plan(z,kind); values=encode(plan,atoms)
                if not np.array_equal(decode_batch(prepare_query_runtime(plan),values,qs),expected): raise AssertionError('matched width values')
                for storage in FORMATS:
                    for rep in range(cfg['repetitions']):
                        b=run/'temp'/f'width_{case["id"]}_{width}_{kind}_{storage}_{rep}'
                        bundle_write(b,plan,values,storage)
                        runtime,reloaded=bundle_load(b)
                        if not np.array_equal(reloaded,values): raise AssertionError('width reload')
                        if rep==0:
                            result=fresh_verify(context['verifier'],b,qs,run/'temp/width_verify')
                            if result['answers']!=expected.tolist(): raise AssertionError('width fresh decoder')
                        records.append({'contract_shape':case['id'],'metrics':width,'representation':kind,'storage':storage,'rep':rep,
                                        'rank':z['rank'],'dimension_per_metric':plan['decoder']['dimension'],'counter_count':int(values.size),
                                        'data_origin':'synthetic independently varying valid bounded-history atoms',
                                        'real_data_measurements':False,'same_atoms_for_all_representations':True,'timings_reported':False,
                                        **archive_sizes(b,plan)})
                        shutil.rmtree(b)
            save_table(run/'tables/matched_width_raw.csv',records)
            print('  width sensitivity',case['id'],width,flush=True)
        del all_atoms
    return pd.DataFrame(records)


def maintenance_suite(context):
    cfg=context['config']; run=context['run']; T=40 if cfg['mode']=='SMOKE' else 500
    z=compile_contract({'G':4,'K':20,'lo':[3]*4,'hi':[7]*4,'metrics':4,'value_bound':100,'horizon':T})
    rows=random_rows(cfg['seed']+9,T,4,4,100,30); by_round={t:[] for t in range(T)}
    for row in rows: by_round[row['round_id']].append(row)
    db=run/'temp/maintenance.duckdb'; capture=SealedRoundCapture(db,z); records=[]; batch_size=10
    for start in range(0,T,batch_size):
        ids=list(range(start,min(T,start+batch_size))); batch=[r for t in ids for r in by_round[t]]
        began=time.perf_counter(); result=capture.apply(batch,ids); elapsed=time.perf_counter()-began
        records.append({'batch':len(records),'rounds':len(ids),'rows':len(batch),'elapsed_seconds':elapsed,
                        'rows_per_second':len(batch)/elapsed,'rounds_per_second':len(ids)/elapsed})
    expected=encode(make_plan(z,'RetainQForest'),atomize_rows(rows,z['contract']))
    if not np.array_equal(capture.values(),expected): raise AssertionError('sustained capture reference')
    before=capture.values().copy(); replay=capture.apply(rows,list(range(T)))
    if replay['new_rounds'] or not np.array_equal(capture.values(),before): raise AssertionError('replay not idempotent')
    denials=[]
    bads=[]
    if rows:
        changed=dict(rows[0]); changed['metric_0']=(changed['metric_0']+1)%101
        t=changed['round_id']; bads.append(('conflicting sealed round',[changed]+[r for r in by_round[t] if r is not rows[0]],[t]))
        invalid=dict(rows[0]); invalid['metric_0']=101; bads.append(('out of bound value',[invalid],[invalid['round_id']]))
        invalid=dict(rows[0]); invalid['score']=True; bads.append(('boolean row integer',[invalid],[invalid['round_id']]))
    bads.append(('runtime horizon',[],[T]))
    for label,batch,ids in bads:
        try: capture.apply(batch,ids)
        except (ValueError,OverflowError): denials.append({'check':label,'rejected':True})
        else: raise AssertionError('capture accepted '+label)
    if not np.array_equal(capture.values(),before): raise AssertionError('rejection mutated state')
    capture.close(); save_table(run/'tables/maintenance_batches.csv',records)
    save_table(run/'tables/maintenance_rejections.csv',denials)
    # Real process termination before and after COMMIT, then reopen/replay.
    fault_z=compile_contract({'G':2,'K':3,'lo':[0,0],'hi':[3,3],'metrics':2,'value_bound':20,'horizon':4})
    frows=random_rows(cfg['seed'],4,2,2,20,6); all_ids=list(range(4))
    fexpected=encode(make_plan(fault_z,'RetainQForest'),atomize_rows(frows,fault_z['contract']))
    recovery=[]
    for fault,exitcode in [('before_commit',91),('after_commit',92)]:
        fdb=run/f'temp/fault_{fault}.duckdb'; payload={'contract':fault_z['contract'],'database':str(fdb),'rows':frows,'sealed_ids':all_ids,'fault':fault}
        p=run/f'temp/fault_{fault}.json'; write_json(p,payload)
        proc=subprocess.run([sys.executable,str(context['core']),'--worker','capture_fault','--config',str(p)],capture_output=True,text=True,timeout=120)
        if proc.returncode!=exitcode: raise AssertionError(('fault worker',fault,proc.returncode,proc.stderr))
        recovered=SealedRoundCapture(fdb,fault_z)
        committed=recovered.con.execute('SELECT count(*) FROM round_ledger').fetchone()[0]
        if committed!=(0 if fault=='before_commit' else 4): raise AssertionError('transaction boundary')
        recovered.apply(frows,all_ids)
        if not np.array_equal(recovered.values(),fexpected): raise AssertionError('recovery exactness')
        recovered.close(); recovery.append({'fault':fault,'exit_code':exitcode,'committed_rounds_before_replay':committed,'replay_matches_uninterrupted':True})
    # Interrupted publication must not publish an incomplete bundle or expire producer state.
    fdb=run/'temp/fault_after_commit.duckdb'; destination=run/'bundles/recovered_source_excluded_archive'
    payload={'contract':fault_z['contract'],'database':str(fdb),'destination':str(destination),'verifier':str(context['verifier']),
             'work':str(run/'temp/publish_verify'),'fault':'before_publish'}
    p=run/'temp/publish_fault.json'; write_json(p,payload)
    proc=subprocess.run([sys.executable,str(context['core']),'--worker','publish_fault','--config',str(p)],capture_output=True,text=True,timeout=120)
    if proc.returncode!=93 or destination.exists() or not fdb.exists(): raise AssertionError('publication fault boundary')
    recovered=SealedRoundCapture(fdb,fault_z); publish_capture(recovered,destination,context['verifier'],run/'temp/publish_recovery_verify'); recovered.close()
    # Only this temporary producer database is expired; external dataset caches are never deleted.
    fdb.unlink(); fdb.with_suffix(fdb.suffix+'.wal').unlink(missing_ok=True)
    queries=[list(q) for q in itertools.product(range(4),repeat=2) if sum(q)==3]
    result=fresh_verify(context['verifier'],destination,queries,run/'temp/post_expiry_verify')
    if result['answers']!=oracle_raw(frows,queries,2,3,2).tolist(): raise AssertionError('post-publication decode')
    recovery.append({'fault':'before_atomic_publish','exit_code':93,'producer_present_until_valid_publish':True,'replay_matches_uninterrupted':True})
    save_table(run/'tables/recovery_checks.csv',recovery)
    return {'batches':len(records),'rows':len(rows),'rounds':T,'ingestion_seconds':sum(x['elapsed_seconds'] for x in records),
            'idempotent_replay':True,'rejections':len(denials),'process_crash_checks':len(recovery),
            'scope':'single-writer sealed complete rounds; no arbitrary late tuple updates; source-excluded directory is not OS isolation'}


def summary_tables(context):
    run=context['run']; rng=np.random.default_rng(context['config']['seed']); outputs={}
    path=run/'tables/benchmark_raw.csv'
    if path.exists():
        raw=pd.read_csv(path); rows=[]
        fields=['encode_seconds','finalize_seconds','fresh_verify_process_seconds','state_load_and_query_setup_seconds',
                'warm_single_query_seconds','warm_all_policy_batch_seconds','total_bundle_bytes','state_file_bytes','metadata_bytes','value_payload_bytes']
        for key,group in raw.groupby(['case','dataset','representation','storage'],sort=False):
            record=dict(zip(['case','dataset','representation','storage'],key)); record['repetitions']=len(group)
            for field in fields:
                a=group[field].to_numpy(dtype=float); med=float(np.median(a)); samples=np.median(rng.choice(a,(2000,len(a)),replace=True),axis=1)
                record[field+'_median']=med; record[field+'_p95']=float(np.quantile(a,.95))
                record[field+'_ci95_low'],record[field+'_ci95_high']=map(float,np.quantile(samples,[.025,.975]))
            for field in ['metrics','policies','rank','dimension_per_metric','counter_count']:
                record[field]=int(group[field].iloc[0])
            rows.append(record)
        outputs['benchmark_summary']=save_table(run/'tables/benchmark_summary.csv',rows)
        common=raw.groupby(['case','rep'],as_index=False)[['input_load_seconds','common_rank_atomize_seconds']].first()
        common.to_csv(run/'tables/common_preprocessing.csv',index=False)
    path=run/'tables/matched_width_raw.csv'
    if path.exists():
        raw=pd.read_csv(path); widths=[]
        for key,g in raw.groupby(['contract_shape','metrics','representation','storage'],sort=False):
            record=dict(zip(['contract_shape','metrics','representation','storage'],key))
            for field in ['value_payload_bytes','state_file_bytes','metadata_bytes','total_bundle_bytes']:
                record[field]=int(g[field].median())
            record.update(fresh_materializations=len(g),identical_file_sizes=g.total_bundle_bytes.nunique()==1,
                          identical_state_hashes=g.state_sha256.nunique()==1,
                          identical_complete_bundle_hashes=g.bundle_content_sha256.nunique()==1,
                          real_data_measurements=False)
            widths.append(record)
        outputs['width_summary']=save_table(run/'tables/matched_width_summary.csv',widths)
        crossover=[]; f=outputs['width_summary']
        for (case,storage),group in f.groupby(['contract_shape','storage']):
            pivot=group.pivot(index='metrics',columns='representation',values='total_bundle_bytes')
            for baseline in ['PrunedRankMarginals','AllPolicyMaterialise']:
                winning=pivot.index[pivot['RetainQForest']<pivot[baseline]].tolist()
                crossover.append({'contract_shape':case,'storage':storage,'baseline':baseline,
                                  'first_tested_width_with_smaller_forest_bundle':min(winning) if winning else None,
                                  'observed_crossover':bool(winning),'synthetic_sensitivity_only':True,
                                  'not_exact_threshold':'first tested point; do not call it the exact break-even'})
        save_table(run/'tables/matched_width_crossover.csv',crossover)
    return outputs


def figures_and_report(context,summaries):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    run=context['run']; f=summaries.get('benchmark_summary')
    if f is not None:
        selected=[x for x in ['A1','M1','D9','D0','D3'] if x in set(f.case)]
        fig,axes=plt.subplots(1,2,figsize=(11,4.2))
        colors=['#64748b','#0f766e','#ca8a04','#2563eb']; x=np.arange(len(selected)); w=.18
        for j,kind in enumerate(KINDS):
            subset=f[(f.representation==kind)&(f.storage=='binary')].set_index('case')
            y=[subset.loc[c,'total_bundle_bytes_median']/1024 for c in selected]
            axes[0].bar(x+(j-1.5)*w,y,w,label=kind,color=colors[j])
            y=[subset.loc[c,'dimension_per_metric'] for c in selected]
            axes[1].bar(x+(j-1.5)*w,y,w,color=colors[j])
        axes[0].set_ylabel('Complete compact archive (KiB)'); axes[1].set_ylabel('Counters per metric')
        for ax in axes:
            ax.set_xticks(x,selected); ax.set_yscale('log'); ax.grid(axis='y',alpha=.2)
        fig.legend(loc='upper center',ncol=2,frameon=False); fig.tight_layout(rect=(0,0,1,.86))
        fig.savefig(run/'figures/matched_storage_and_dimension.png',dpi=180,bbox_inches='tight')
        fig.savefig(run/'figures/matched_storage_and_dimension.pdf',bbox_inches='tight'); plt.close(fig)
    w=summaries.get('width_summary')
    if w is not None:
        cases=list(w.contract_shape.unique()); fig,axes=plt.subplots(1,len(cases),figsize=(4.2*len(cases),3.8),squeeze=False)
        for ax,case in zip(axes.flat,cases):
            for kind,marker in [('PrunedRankMarginals','s'),('AllPolicyMaterialise','^'),('RetainQForest','o')]:
                a=w[(w.contract_shape==case)&(w.storage=='binary')&(w.representation==kind)].sort_values('metrics')
                ax.plot(a.metrics,a.total_bundle_bytes/1024,marker=marker,label=kind)
            ax.set(xscale='log',yscale='log',xlabel='Synthetic independent observables',ylabel='Complete compact archive (KiB)',title=case+' contract shape'); ax.grid(alpha=.2)
        axes.flat[0].legend(fontsize=8); fig.tight_layout()
        fig.savefig(run/'figures/matched_width_synthetic.png',dpi=180,bbox_inches='tight'); fig.savefig(run/'figures/matched_width_synthetic.pdf',bbox_inches='tight'); plt.close(fig)
    lines=['# RetainQ V6 evidence report','',f'Mode: {context["config"]["mode"]}. CPU only. No minimum speedup/storage-saving threshold was used.','',
           'Measured full-data results and synthetic contract-shape sensitivity are separate. All-policy materialization is a primary baseline. Test expected answers are stored outside retained bundles.','',
           'Common input loading and rank/atom construction are reported separately from representation encoding, finalization, fresh-process verification, state loading, and warm queries. All methods receive the same shared atoms, use exact integer arithmetic, and can load state once for batch queries.','']
    if f is not None:
        lines.extend(['| Case | Representation | Counters/metric | Complete binary bytes | Warm batch seconds |','|---|---|---:|---:|---:|'])
        for _,row in f[f.storage=='binary'].sort_values(['case','representation']).iterrows():
            lines.append(f'| {row["case"]} | {row.representation} | {row.dimension_per_metric} | {row.total_bundle_bytes_median:.0f} | {row.warm_all_policy_batch_seconds_median:.6f} |')
    lines.extend(['','## Interpretation limits','',
                  '- ACS/MovieLens contracts are selected mechanism probes, not evidence of deployed audit-policy prevalence.',
                  '- The width study uses synthetically generated, jointly matched, realizable bounded-history atoms. Its extra observables are not real ACS/MovieLens measurements.',
                  '- In the box family, compare rank with min(pruned counters, all-policy answers). The closed-form rank baseline must accompany graph compilation.',
                  '- Archive verification checks structural and numeric consistency. It does not prove honest capture, regulatory erasure, privacy, or cryptographic source provenance.',
                  '- Maintenance supports one writer and complete immutable sealed rounds. Crash checks are at transaction/publication boundaries, not a general distributed failure model.',
                  '- Fresh verifier processes can access the surrounding machine; four-file archives do not establish OS-level isolation.',
                  '- Smoke results are setup checks and must not be used as confirmatory paper results.',
                  '- New implementation timings do not retroactively validate V5 timing figures. Do not reuse the old 47.2% W0 claim without a matching new table.'])
    (run/'EVIDENCE_REPORT.md').write_text('\n'.join(lines)+'\n')
    return str(run/'EVIDENCE_REPORT.md')


def export_results(context,allow_incomplete=False):
    run=context['run']; statuses={p.stem:read_json(p) for p in (run/'checks').glob('*_status.json')}
    expected={'validation_status','compiler_status','data_status','benchmarks_status','width_status','maintenance_status','summaries_status'}
    complete=expected<=set(statuses) and all(statuses[k].get('status')=='passed' for k in expected)
    if not complete and not allow_incomplete: raise AssertionError('required stages have not all passed; use incomplete export for debugging only')
    write_json(run/'manifests/run_status.json',{'complete':complete,'mode':context['config']['mode'],'statuses':statuses,
               'suitable_for_confirmatory_reporting':complete and context['config']['mode']=='CONFIRMATORY' and context['config']['include_real']})
    files=[p for p in run.rglob('*') if p.is_file() and 'temp' not in p.relative_to(run).parts and '__pycache__' not in p.parts]
    write_json(run/'manifests/checksums.json',{str(p.relative_to(run)):sha256_file(p) for p in files if p.name!='checksums.json'})
    archive=run.parent/(run.name+('_INCOMPLETE' if not complete else '')+'.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in run.rglob('*'):
            if p.is_file() and 'temp' not in p.relative_to(run).parts and '__pycache__' not in p.parts:
                z.write(p,str(Path(run.name)/p.relative_to(run)))
    print('Results archive:',archive,flush=True)
    return archive



if __name__ == '__main__':
    worker_main()
