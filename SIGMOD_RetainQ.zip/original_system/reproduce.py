"""Reproduce the previously completed V6 system study; not used by the focused study."""
import argparse
import retainq_v6 as rq


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root',default='original_system_runs')
    parser.add_argument('--mode',choices=('SMOKE','CONFIRMATORY'),default='CONFIRMATORY')
    parser.add_argument('--existing-cache',default='')
    args=parser.parse_args()
    context=rq.configure_run(args.output_root,mode=args.mode,include_real=True,seed=20261018)
    rq.stage(context,'validation',lambda:rq.validation_suite(context))
    rq.stage(context,'compiler',lambda:rq.compiler_suite(context))
    datasets=rq.stage(context,'data',lambda:rq.prepare_data(context,args.existing_cache))
    cases=rq.workload_specs(context,datasets)
    rq.stage(context,'benchmarks',lambda:rq.benchmark_suite(context,cases))
    rq.stage(context,'width',lambda:rq.width_suite(context,cases))
    rq.stage(context,'maintenance',lambda:rq.maintenance_suite(context))
    summaries=rq.stage(context,'summaries',lambda:rq.summary_tables(context))
    rq.figures_and_report(context,summaries)
    rq.export_results(context)


if __name__=='__main__':main()
