"""Standalone structural verifier. Does not import the producer or contain expected answers.
This checks consistency with a declared contract, not truth/provenance of deleted source data.
"""
import argparse, hashlib, itertools, json, time
from pathlib import Path
import numpy as np
import duckdb


def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()


def contract_check(c):
    keys={'G','K','lo','hi','metrics','value_bound','horizon','word_bits','family','arithmetic','granularity','semantics'}
    if type(c) is not dict or set(c)!=keys: raise ValueError('contract schema')
    for k in ['G','K','metrics','horizon']:
        if type(c[k]) is not int or c[k]<1: raise ValueError('integer contract field')
    if type(c['value_bound']) is not int or c['value_bound']<0: raise ValueError('value bound')
    if type(c['word_bits']) is not int or c['word_bits']!=64: raise ValueError('word width')
    if (c['family'],c['arithmetic'],c['granularity'])!=('bounded_fixed_capacity','integer','cumulative'): raise ValueError('unsupported semantics')
    for k in ['lo','hi']:
        if type(c[k]) is not list or len(c[k])!=c['G'] or any(type(x) is not int for x in c[k]): raise ValueError('quota interval schema')
    if any(l<0 or l>u or u>c['K'] for l,u in zip(c['lo'],c['hi'])) or not sum(c['lo'])<=c['K']<=sum(c['hi']): raise ValueError('quota interval')
    if c['horizon']>(2**63-1)//max(1,c['K']*c['value_bound']): raise OverflowError('horizon')
    s=c['semantics']
    if type(s) is not dict or set(s)!={'ranking','grouping','observables','rounds','missing_positions'}: raise ValueError('semantic metadata')
    if s['ranking']!='score DESC, candidate_id ASC' or s['rounds']!='complete immutable sealed rounds' or s['missing_positions']!='zero; shortfall is not redistributed': raise ValueError('unsupported atomization')
    if type(s['grouping']) is not str or not s['grouping'] or type(s['observables']) is not list or len(s['observables'])!=c['metrics'] or any(type(x) is not str or not x for x in s['observables']): raise ValueError('measure/group definitions')


def policy_check(q,c):
    if type(q) not in (list,tuple) or len(q)!=c['G'] or any(type(x) is not int for x in q): raise ValueError('policy type')
    if sum(q)!=c['K'] or any(x<l or x>u for x,l,u in zip(q,c['lo'],c['hi'])): raise ValueError('policy outside contract')


def policies(c):
    # Enumerate only when a declared all-policy representation is itself bounded.
    def visit(i,left,prefix):
        if i==c['G']:
            if left==0: yield tuple(prefix)
            return
        low=max(c['lo'][i],left-sum(c['hi'][i+1:])); high=min(c['hi'][i],left-sum(c['lo'][i+1:]))
        for q in range(low,high+1): yield from visit(i+1,left-q,prefix+[q])
    yield from visit(0,c['K'],[])


def structure(c):
    low=[max(l,c['K']-(sum(c['hi'])-c['hi'][g])) for g,l in enumerate(c['lo'])]
    high=[min(u,c['K']-(sum(c['lo'])-c['lo'][g])) for g,u in enumerate(c['hi'])]
    vertices=[(g,r) for g in range(c['G']) for r in range(low[g]+1,high[g]+1)]
    edges=set()
    for a,b in itertools.combinations(vertices,2):
        g,r=a; h,s=b
        if g==h: continue
        residual=c['K']-r-s+1
        if sum(c['lo'])-c['lo'][g]-c['lo'][h]<=residual<=sum(c['hi'])-c['hi'][g]-c['hi'][h]: edges.add((a,b))
    parent={v:v for v in vertices}
    def root(v):
        while parent[v]!=v:
            parent[v]=parent[parent[v]]; v=parent[v]
        return v
    for a,b in edges:
        a,b=root(a),root(b)
        if a!=b: parent[a]=b
    groups={}
    for v in vertices: groups.setdefault(root(v),[]).append(v)
    components=sorted(sorted(v) for v in groups.values())
    return low,high,vertices,edges,components,1+len(vertices)-len(components)


def inspect_decoder(c,d,info):
    low,high,vertices,edges,components,rank=info
    kind=d.get('kind'); dim=d.get('dimension')
    if type(dim) is not int or dim<1 or d.get('schema_version')!=1: raise ValueError('decoder dimension/version')
    if kind=='RetainQForest':
        if set(d)!={'schema_version','kind','dimension','q0','vertices','roots','oriented_edges'} or dim!=rank: raise ValueError('forest schema/rank')
        policy_check(d['q0'],c)
        if d['vertices']!=[list(v) for v in vertices] or d['roots']!=[list(min(x)) for x in components]: raise ValueError('forest vertex/root coverage')
        rootset={tuple(v) for v in d['roots']}; parents={}; basis={}; uf={v:v for v in vertices}
        def find(v):
            while uf[v]!=v: v=uf[v]
            return v
        seen=set()
        for e in d['oriented_edges']:
            if type(e) is not dict or set(e)!={'basis_id','child','parent','witness'} or type(e['basis_id']) is not int: raise ValueError('edge schema')
            a,b=tuple(e['child']),tuple(e['parent'])
            if tuple(sorted((a,b))) not in edges or a in parents or a in rootset: raise ValueError('invalid edge/orientation')
            x,y=find(a),find(b)
            if x==y: raise ValueError('forest cycle')
            uf[x]=y; parents[a]=b; basis[a]=e['basis_id']; seen.add(e['basis_id'])
            q=e['witness']; policy_check(q,c); witnessed=False
            for added,removed in [(a,b),(b,a)]:
                g,r=added; h,s=removed
                if q[g]==r-1 and q[h]==s:
                    other=list(q); other[g]+=1; other[h]-=1
                    try: policy_check(other,c); witnessed=True
                    except ValueError: pass
            if not witnessed: raise ValueError('edge witness')
        if seen!=set(range(1,rank)) or len(d['oriented_edges'])!=rank-1 or set(parents)!=set(vertices)-rootset: raise ValueError('forest coverage')
        for comp in components:
            if len({find(v) for v in comp})!=1: raise ValueError('unspanned component')
        return {'parents':parents,'basis':basis,'roots':rootset}
    if set(d)!={'schema_version','kind','dimension'}: raise ValueError('simple decoder schema')
    if kind=='RawRankMarginals' and dim==c['G']*c['K']: return {}
    if kind=='PrunedRankMarginals' and dim==len(vertices)+int(sum(low)>0): return {}
    if kind=='AllPolicyMaterialise':
        family=list(itertools.islice(policies(c),10001))
        if len(family)>10000 or dim!=len(family): raise ValueError('all-policy dimension/cap')
        return {'policy_index':{q:i for i,q in enumerate(family)}}
    raise ValueError('unsupported representation or wrong dimension')


def verify(bundle,queries):
    start=time.perf_counter(); b=Path(bundle)
    if not b.is_dir() or any(p.is_symlink() or not p.is_file() for p in b.iterdir()): raise ValueError('archive directory/files')
    c=json.loads((b/'contract.json').read_text()); contract_check(c)
    d=json.loads((b/'decoder.json').read_text()); cert=json.loads((b/'certificate.json').read_text())
    wanted={'schema_version','implementation_version','storage','counter_dimension_per_metric','minimum_linear_rank','contract_sha256','decoder_sha256','state_sha256','state_file','metric_count','source_provenance_proved'}
    if type(cert) is not dict or set(cert)!=wanted or cert['schema_version']!=1 or cert['source_provenance_proved'] is not False: raise ValueError('certificate schema')
    filename={'binary':'retained_state.bin','duckdb':'retained_state.duckdb'}.get(cert['storage'])
    if filename is None or cert['state_file']!=filename or {p.name for p in b.iterdir()}!={filename,'contract.json','decoder.json','certificate.json'}: raise ValueError('four-file allowlist')
    if sha(b/'contract.json')!=cert['contract_sha256'] or sha(b/'decoder.json')!=cert['decoder_sha256'] or sha(b/filename)!=cert['state_sha256']: raise ValueError('content hash')
    info=structure(c); auxiliary=inspect_decoder(c,d,info)
    if cert['minimum_linear_rank']!=info[-1] or cert['counter_dimension_per_metric']!=d['dimension'] or cert['metric_count']!=c['metrics']: raise ValueError('certificate dimensions')
    dim=d['dimension']; count=c['metrics']*dim
    if cert['storage']=='binary':
        if (b/filename).stat().st_size!=count*8: raise ValueError('binary length')
        values=np.fromfile(b/filename,dtype='<i8').reshape(c['metrics'],dim)
    else:
        con=duckdb.connect(str(b/filename),read_only=True)
        try:
            if con.execute('SHOW TABLES').fetchall()!=[('retained_state',)]: raise ValueError('state tables')
            cols=con.execute("PRAGMA table_info('retained_state')").fetchall()
            if [(r[1],r[2]) for r in cols]!=[('metric_id','INTEGER'),('basis_id','INTEGER'),('value','BIGINT')]: raise ValueError('state schema/types')
            rows=con.execute('SELECT metric_id,basis_id,value FROM retained_state ORDER BY metric_id,basis_id').fetchall()
        finally: con.close()
        if len(rows)!=count or any((m,k)!=(i//dim,i%dim) or v is None for i,(m,k,v) in enumerate(rows)): raise ValueError('dense keys')
        values=np.asarray([r[2] for r in rows],dtype=np.int64).reshape(c['metrics'],dim)
    atom_bound=c['value_bound']*c['horizon']; base_bound=c['K']*atom_bound
    kind=d['kind']; low=info[0]; vertices=info[2]
    for m in range(c['metrics']):
        for i,x in enumerate(values[m]):
            x=int(x)
            if kind=='RetainQForest':
                ok=0<=x<=base_bound if i==0 else abs(x)<=atom_bound
            elif kind=='AllPolicyMaterialise': ok=0<=x<=base_bound
            elif kind=='PrunedRankMarginals' and sum(low)>0 and i==0: ok=0<=x<=sum(low)*atom_bound
            else: ok=0<=x<=atom_bound
            if not ok: raise OverflowError('state coordinate outside certified bound')
    answers=[]
    for q in queries:
        policy_check(q,c); total=[]
        if kind=='RetainQForest':
            # Reconstruct each tree potential from stored endpoint differences, then evaluate
            # the component-balanced response difference. This differs from producer subtree coefficients.
            potential={v:0 for v in auxiliary['roots']}; pending=list(d['oriented_edges'])
            order=[]
            while pending:
                done=[]
                for j,e in enumerate(pending):
                    child,parent=tuple(e['child']),tuple(e['parent'])
                    if parent in potential:
                        potential[child]=0; order.append(e); done.append(j)
                if not done: raise ValueError('unrooted forest')
                pending=[e for j,e in enumerate(pending) if j not in set(done)]
            for m in range(c['metrics']):
                p={v:0 for v in auxiliary['roots']}
                for e in order: p[tuple(e['child'])]=p[tuple(e['parent'])]+int(values[m,e['basis_id']])
                answer=int(values[m,0])+sum((int(r<=q[g])-int(r<=d['q0'][g]))*p[(g,r)] for g,r in vertices)
                total.append(answer)
        elif kind=='AllPolicyMaterialise': total=[int(v) for v in values[:,auxiliary['policy_index'][tuple(q)]]]
        elif kind=='RawRankMarginals':
            total=[sum(int(values[m,g*c['K']+r-1]) for g in range(c['G']) for r in range(1,q[g]+1)) for m in range(c['metrics'])]
        else:
            offset=int(sum(low)>0)
            total=[(int(values[m,0]) if offset else 0)+sum(int(values[m,i+offset]) for i,(g,r) in enumerate(vertices) if r<=q[g]) for m in range(c['metrics'])]
        if any(x<0 or x>base_bound for x in total): raise OverflowError('decoded answer outside contract')
        answers.append(total)
    return {'accepted':True,'minimum_linear_rank':info[-1],'representation_dimension':dim,
            'queries':len(queries),'answers':answers,'source_provenance_proved':False,
            'elapsed_seconds':time.perf_counter()-start}


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--bundle',required=True); p.add_argument('--queries',required=True); p.add_argument('--output',required=True)
    a=p.parse_args(); result=verify(a.bundle,json.loads(Path(a.queries).read_text())); Path(a.output).write_text(json.dumps(result,indent=2))
