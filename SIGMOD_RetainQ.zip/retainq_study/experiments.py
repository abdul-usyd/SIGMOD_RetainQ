"""Predeclared source-feasibility, sensitivity and validation experiments."""
from __future__ import annotations
import itertools, json, math, random, statistics, time
from pathlib import Path
import numpy as np
from . import exact, structural, source


def check(context,name,count=1,**details):
    row={'check':name,'passed':True,'count':int(count),**details}
    context['checks'].append(row)
    return row


def capture_cached(data,cache,edits=None):
    tag='base' if edits is None else 'edited'
    array_path=Path(cache)/f'independent_source_capture{ "" if edits is None else "_edited"}.npz'
    receipt_path=array_path.with_suffix('.json')
    edit_digest=exact.sha(json.dumps(edits or [],sort_keys=True).encode())
    implementation=source.digest(Path(source.__file__))
    if array_path.exists() and receipt_path.exists():
        receipt=json.loads(receipt_path.read_text())
        matches=(receipt['source']['ratings_sha256']==data['provenance']['ratings_sha256'] and
                 receipt['source']['movies_sha256']==data['provenance']['movies_sha256'] and
                 receipt.get('implementation_sha256')==implementation and
                 receipt['npz_sha256']==source.digest(array_path) and
                 receipt.get('edit_digest',exact.sha(b'[]'))==edit_digest)
        if not matches:raise ValueError('stale source capture cache; delete this capture cache and rerun')
    else:
        start=time.perf_counter();captured=source.sql_capture(data,Path(cache)/('oracle_'+tag),edits)
        np.savez_compressed(array_path,**{f'G{g}_H{h}':a for (g,h),a in captured['captures'].items()},
                            **{f'direct_G{g}':a for g,a in captured['direct'].items()})
        receipt={k:v for k,v in captured.items() if k not in ('captures','direct')}
        receipt.update(source=data['provenance'],edit_digest=edit_digest,
                       implementation_sha256=implementation,npz_sha256=source.digest(array_path),
                       seconds_diagnostic_only=time.perf_counter()-start)
        exact.dump_json(receipt_path,receipt)
    arrays=np.load(array_path,allow_pickle=False)
    return {k:arrays[k] for k in arrays.files},receipt


def verify_real_source(context,arrays,receipt):
    comparisons=[]
    for case,G in [('M0',5),('M1',2)]:
        truth=np.array(context['bundles'][case]['RawRankMarginals']['values'],dtype=np.int64)
        observed=arrays[f'G{G}_H162541']
        assert np.array_equal(truth,observed),(case,'independent full-source discrepancy')
        info=context['analyses'][case]
        for kind in exact.KINDS:
            E=exact.representation_rows(info,kind,context['bundles'][case][kind]['decoder'])
            state=exact.evaluate_rows(E,observed.tolist())
            assert state==context['bundles'][case][kind]['values']
            comparisons.append({'case':case,'representation':kind,'fresh_source_matches_frozen_state':True,
                                'source_rows':receipt['source_rows'],'source_rounds':receipt['source_rounds']})
    matrix=np.array(context['analyses']['M1']['rows'],dtype=np.int64)
    assert np.array_equal(arrays['G2_H162541']@matrix.T,arrays['direct_G2'])
    exact.save_csv(context['run']/'tables/fresh_source_validation.csv',comparisons)
    exact.dump_json(context['run']/'provenance/independent_source_capture.json',receipt)
    check(context,'Full MovieLens CSV parser/window oracle matches all eight frozen M0/M1 states',8,
          source_rows=receipt['source_rows'],source_rounds=receipt['source_rounds'])


def disclosure_profile(context):
    aggregate=[];details=[]
    for case,info in context['analyses'].items():
        component={p:i for i,comp in enumerate(info['components']) for p in comp}
        reachable=[p for p in info['positions'] if p not in info['unreachable']]
        recovered=0
        for left,right in itertools.combinations(reachable,2):
            target=[0]*len(info['positions']);target[info['columns'][left]]=1;target[info['columns'][right]]=-1
            structural=(left in component and right in component and component[left]==component[right])
            answer=info['span'].contains(target)
            assert structural==answer
            recovered+=answer
            details.append({'case':case,'first_group':left[0],'first_rank':left[1],
                            'second_group':right[0],'second_rank':right[1],
                            'difference_unavoidably_linearly_recoverable':answer})
        assert recovered==sum(math.comb(len(c),2) for c in info['components'])
        aggregate.append({'case':case,'reachable_positions':len(reachable),
            'all_reachable_pairwise_contrasts':math.comb(len(reachable),2),
            'unavoidably_recoverable_pairwise_contrasts':recovered,
            'nonmembership_is_not_general_privacy':True})
    exact.save_csv(context['run']/'tables/linear_disclosure_profile.csv',aggregate)
    exact.save_csv(context['run']/'tables/pairwise_contrast_membership.csv',details)
    context['disclosure_profile']=aggregate
    check(context,'Every reachable pairwise contrast: structural test agrees with exact rational membership',len(details))
    return aggregate


def fixed_catalogue_experiment(context,data,arrays,cache,config):
    K=10;info=context['analyses']['M1'];A=np.array(info['rows'],dtype=np.int64)
    rounds=source.load_prefix(data,config['candidate_user_prefix'])
    pools=source.discover_moves(rounds,data,K,config['candidates_per_label_cap'])
    edits=source.select_disjoint_gadgets(pools,K)
    direct_before={};direct_after={};deltas={};per_edit=[]
    zero=np.zeros((2,20),dtype=np.int64)
    for edit in edits:
        uid=edit['user_id'];before=rounds[uid];after=source.apply_edit(before,edit)
        ga=source.ranked_groups(before,data['catalogue'],2,K)
        gb=source.ranked_groups(after,data['catalogue'],2,K)
        expected_ids=[[v[0] for v in group] for group in ga]
        expected_ids[edit['group']][edit['rank']-1]=edit['new_movie_id']
        assert [[v[0] for v in group] for group in gb]==expected_ids
        assert sorted((s,t) for _,s,t in before)==sorted((s,t) for _,s,t in after)
        assert len(before)==len(after) and len({m for m,_,_ in after})==len(after)
        assert data['catalogue'][edit['new_movie_id']]-data['catalogue'][edit['old_movie_id']]==edit['year_shift']
        aa=source.round_atoms(before,data['catalogue']);bb=source.round_atoms(after,data['catalogue'])
        target=np.zeros((2,20),dtype=np.int64);target[1,edit['group']*K+edit['rank']-1]=edit['year_shift']
        assert np.array_equal(bb-aa,target)
        ya=source.direct_round_answers(before,data['catalogue'],info['policies'])
        yb=source.direct_round_answers(after,data['catalogue'],info['policies'])
        assert np.array_equal(aa@A.T,ya) and np.array_equal(bb@A.T,yb)
        direct_before[uid]=ya;direct_after[uid]=yb;deltas[uid]=target
        per_edit.append({'edit_id':edit['edit_id'],'direction':edit['direction'],'source_user_id':uid,
                         'group':edit['group'],'rank':edit['rank'],'old_movie_id':edit['old_movie_id'],
                         'new_movie_id':edit['new_movie_id'],'single_year_metric_cell_changes':True,
                         'fixed_catalogue':True,'ratings_timestamps_and_counts_unchanged':True,
                         'ranking_preserved_except_movie_identity':True,
                         'round_before_sha256':exact.sha(json.dumps(before).encode()),
                         'round_after_sha256':exact.sha(json.dumps(after).encode())})
    assert len({e['user_id'] for e in edits})==36
    directions=[];direction_rows=[]
    for r in range(1,K):
        group=[e for e in edits if e['direction']==r]
        delta=sum((deltas[e['user_id']] for e in group),zero.copy())
        expected=zero.copy()
        for g,rank,shift in [(0,r,1),(1,K+1-r,1),(0,K,-1),(1,1,-1)]:expected[1,g*K+rank-1]+=shift
        assert np.array_equal(delta,expected)
        raw_answer_change=sum((direct_after[e['user_id']]-direct_before[e['user_id']] for e in group),np.zeros((2,11),dtype=np.int64))
        assert not np.any(raw_answer_change) and not np.any(delta@A.T)
        directions.append(delta)
        direction_rows.append({'direction':r,'source_edits':4,'distinct_users':4,'year_metric_cells_changed':4,
                               'all_22_policy_metric_answers_unchanged':True,'year_null_direction_independent':True})
    D=np.array([d[1] for d in directions],dtype=np.int64)
    assert exact.ExactSpan(D.tolist()).rank==9
    assert exact.ExactSpan(A.tolist()).rank==11 and A.shape[1]-11==9
    bitvectors=np.array(list(itertools.product((0,1),repeat=9)),dtype=np.int64)
    shifts=bitvectors@D
    assert len({tuple(row) for row in shifts})==512
    assert not np.any(shifts@A.T)
    comparisons=[]
    for kind in exact.KINDS:
        E=np.array(exact.representation_rows(info,kind,context['bundles']['M1'][kind]['decoder']),dtype=np.int64)
        state_changes=shifts@E.T
        distinct=len({tuple(row) for row in state_changes})
        actual_base=np.array(context['bundles']['M1'][kind]['values'],dtype=np.int64)
        payload_hashes=set()
        for changed in state_changes:
            state=actual_base.copy();state[1]+=changed
            payload_hashes.add(exact.sha(state.astype('<i8').tobytes()))
        assert len(payload_hashes)==distinct
        assert distinct==(1 if kind in ('AllPolicyMaterialise','RetainQForest') else 512)
        comparisons.append({'representation':kind,'stored_counters_per_metric':E.shape[0],
                            'distinct_states_across_512_feasible_worlds':distinct,
                            'distinct_encoded_payload_sha256_values':len(payload_hashes),
                            'all_512_worlds_have_identical_authorised_answers':True,
                            'source_feasible_year_affine_dimension':9})
    # Verify every composed world's answers from independent direct-record per-round
    # evaluations. Disjoint users mean every round chooses exactly one valid version.
    source_world_rows=[]
    for bits,shift in zip(bitvectors,shifts):
        ydelta=np.zeros((2,11),dtype=np.int64);source_edits=0
        for edit in edits:
            if bits[edit['direction']-1]:
                ydelta+=direct_after[edit['user_id']]-direct_before[edit['user_id']];source_edits+=1
        assert not np.any(ydelta)
        source_world_rows.append({'world_mask':sum(int(b)<<i for i,b in enumerate(bits)),
            'source_movie_substitutions':source_edits,'catalogue_identical':True,
            'all_22_answers_equal_from_direct_source_selection':True,
            'different_year_rank_coordinates':int(np.count_nonzero(shift))})
    horizon_rows=[]
    total_delta=sum(directions,zero.copy())
    for H in config['horizons']:
        assert max(e['user_id'] for e in edits)<=H
        before=arrays[f'G2_H{H}'];after=before+total_delta
        assert not np.any(after<0) and np.array_equal(before@A.T,after@A.T)
        horizon_rows.append({'source_users':H,'source_edits':36,'distinct_feasible_worlds_certified':512,
            'reachable_year_rank_positions':20,'answer_rank':11,'feasible_year_affine_dimension':9,
            'all_22_answers_equal':True,'all_20_individual_year_cells_vary_across_compatible_worlds':bool(np.all(np.any(shifts!=0,axis=0))),
            'maximum_cumulative_year_metric_change':int(np.max(np.abs(total_delta[1])))})
    # Full re-sort of all 25M records after all 36 edits; no delta shortcut.
    edited,edited_receipt=capture_cached(data,cache,edits)
    for H in config['horizons']:
        assert np.array_equal(edited[f'G2_H{H}'],arrays[f'G2_H{H}']+total_delta)
    assert np.array_equal(edited['direct_G2'],arrays['direct_G2'])
    m0=context['analyses']['M0'];m0_matrix=np.array(m0['rows'],dtype=np.int64)
    m0_changed=np.any((edited['G5_H162541']-arrays['G5_H162541'])@m0_matrix.T,axis=0)
    # Positive controls: one incomplete pair, then one component shift, must change answers.
    first=[e for e in edits if e['direction']==1]
    single=deltas[first[0]['user_id']]
    pair=sum((deltas[e['user_id']] for e in first if e['year_shift']==1),zero.copy())
    assert np.any(single@A.T) and np.all((pair@A.T)[1]==1)
    probe=(1,0);probe_row=np.array(exact.policy_row(probe,K))
    assert tuple(probe) not in info['policies'] and not info['span'].contains(probe_row.tolist())
    assert np.any(shifts@probe_row)
    prefix_rows=[]
    for horizon in range(1,max(e['user_id'] for e in edits)+1):
        delta=sum((deltas[e['user_id']] for e in edits if e['user_id']<=horizon),zero.copy())
        changed=delta@A.T
        prefix_rows.append({'prefix_users':horizon,
            'changed_permitted_policy_metric_answers':int(np.count_nonzero(changed)),
            'maximum_answer_difference':int(np.max(np.abs(changed))),
            'cumulative_prefix_answers_identical':not bool(np.any(changed))})
    assert any(not r['cumulative_prefix_answers_identical'] for r in prefix_rows)
    controls=[{'control':'single unbalanced substitution','expected':'authorised answers change','passed':True},
              {'control':'one component shifts without compensating component','expected':'all 11 year answers increase by one','passed':True},
              {'control':'out-of-contract quota (1,0)','expected':'distinguishes some answer-equivalent histories','passed':True},
              {'control':'independent full-source re-sort of all 36 substitutions','expected':'matches algebra and all 22 unchanged answers','passed':True},
              {'control':'release every intermediate user-prefix answer','expected':'distinguishes the histories; equivalence concerns one sealed cumulative horizon','passed':True}]
    exact.save_csv(context['run']/'tables/fixed_catalogue_edits.csv',per_edit)
    exact.save_csv(context['run']/'tables/fixed_catalogue_directions.csv',direction_rows)
    exact.save_csv(context['run']/'tables/fixed_catalogue_worlds.csv',source_world_rows)
    exact.save_csv(context['run']/'tables/fixed_catalogue_representations.csv',comparisons)
    exact.save_csv(context['run']/'tables/horizon_sensitivity.csv',horizon_rows)
    exact.save_csv(context['run']/'tables/source_controls.csv',controls)
    exact.save_csv(context['run']/'tables/prefix_release_sensitivity.csv',prefix_rows)
    exact.save_csv(context['run']/'tables/candidate_search.csv',[
        {'group':g,'rank':r,'year_shift':s,'candidate_users_recorded':len(pool),
         'candidate_cap':config['candidates_per_label_cap'],'count_is_capped_not_prevalence':True}
        for (g,r,s),pool in sorted(pools.items())])
    # Save source pointers and deltas, never redistribute MovieLens rows/catalogue.
    pointers=[{k:e[k] for k in ('edit_id','direction','user_id','old_movie_id','new_movie_id')} for e in edits]
    exact.dump_json(context['run']/'evidence/source_edit_pointers.json',pointers)
    exact.dump_json(context['run']/'evidence/feasible_year_kernel_basis.json',{'basis':D.tolist(),
                    'rank':9,'nullity_per_metric':9,'catalogue_sha256':data['provenance']['movies_sha256'],
                    'independent_switches':9,'disjoint_source_rounds':36,
                    'combination_proof':'Each switch changes four separate users. Across switches every changed user is distinct. Every subset therefore combines independently validated valid round versions.'})
    exact.dump_json(context['run']/'provenance/edited_full_source_capture.json',edited_receipt)
    result={'dataset':'ml-25m','source_rows':25000095,'source_users':162541,'fixed_catalogue_movies':62423,
        'catalogue_identical_in_every_world':True,'search_users':len(rounds),
        'search_rows':sum(map(len,rounds.values())),'maximum_edited_user_id':max(e['user_id'] for e in edits),
        'disjoint_edited_users':36,'source_movie_substitutions_at_full_switch_setting':36,
        'ratings_timestamps_and_per_user_counts_preserved':True,
        'legal_policy_metric_answers_per_world':22,'distinct_feasible_worlds_certified':512,
        'independent_feasible_year_directions':9,'year_nullity_exact':9,
        'all_20_year_rank_coordinates_nonunique_at_observed_answer_vector':True,
        'year_linear_statistic_identifiability_exactly_characterized_at_observed_answers':True,
        'independent_full_source_capture_passed':True,
        'different_five_group_M0_queries_changed_by_these_M1_preserving_edits':int(np.count_nonzero(m0_changed)),
        'intermediate_prefixes_with_different_authorised_answers':sum(not r['cumulative_prefix_answers_identical'] for r in prefix_rows),
        'release_model':'one sealed cumulative horizon; not a transcript of intermediate prefix or per-user answers',
        'actual_privacy_guarantee':False,
        'all_counterfactuals_are_observed_histories':False,'construction_estimates_population_frequency':False}
    context.update(fixed_catalogue=result,source_world_shifts=shifts,source_directions=D,
                   representation_worlds=comparisons,horizon_rows=horizon_rows)
    check(context,'Fixed catalogue: 36 disjoint valid source substitutions and exact direct-record selection',36)
    check(context,'Nine independent feasible year-metric directions saturate M1 year nullity',9)
    check(context,'All 512 composed source-feasible worlds preserve all 22 authorised answers',512)
    check(context,'Independent full 25M-row edited source capture and four horizon checks',4)
    check(context,'Unbalanced edits, an out-of-contract request and intermediate prefix releases expose changed information',4)
    return result


def enumerate_legal(c):
    lo,hi,K=c['lo'],c['hi'],c['K'];G=len(lo)
    def visit(g,left,prefix):
        if g==G:
            if left==0:yield tuple(prefix)
            return
        a=max(lo[g],left-sum(hi[g+1:]));b=min(hi[g],left-sum(lo[g+1:]))
        for q in range(a,b+1):yield from visit(g+1,left-q,prefix+[q])
    return list(visit(0,K,[]))


def exhaustive_geometry(context):
    total=targets=0;by_setting=[];rng=random.Random(20261018)
    for G,maximum in [(2,5),(3,4)]:
        for K in range(1,maximum+1):
            intervals=[(a,b) for a in range(K+1) for b in range(a,K+1)];count=0
            for pairs in itertools.product(intervals,repeat=G):
                lo,hi=[x[0] for x in pairs],[x[1] for x in pairs]
                if not sum(lo)<=K<=sum(hi):continue
                c={'G':G,'K':K,'lo':lo,'hi':hi};compiled=structural.compile_box(c)
                qs=enumerate_legal(c);rows=[exact.policy_row(q,K) for q in qs]
                span=exact.ExactSpan(rows)
                assert compiled['rank']==span.rank and compiled['policy_count']==len(qs)
                mandatory=[(g,r) for g in range(G) for r in range(1,compiled['lower'][g]+1)]
                E=[[int(r<=compiled['base'][g]) for g in range(G) for r in range(1,K+1)]]
                for a,b in compiled['forest']:
                    row=[0]*(G*K);row[a[0]*K+a[1]-1]=1;row[b[0]*K+b[1]-1]=-1
                    E.append(row)
                    # Verify edge's defining quota feasibility independently.
                    assert any(q[a[0]]==a[1]-1 and q[b[0]]==b[1] for q in qs)
                forestspan=exact.ExactSpan(E)
                assert forestspan.rank==span.rank and all(forestspan.contains(row) for row in rows)
                individually=0
                for g in range(G):
                    for r in range(1,K+1):
                        target=[0]*(G*K);target[g*K+r-1]=1
                        yes=span.contains(target);individually+=yes
                        assert structural.contains_sparse(compiled,{(g,r):1})==yes
                        targets+=1
                assert individually==structural.individually_recoverable(compiled)
                for _ in range(2):
                    target=[rng.randint(-1,1) for _ in range(G*K)]
                    sparse={(g,r):target[g*K+r-1] for g in range(G) for r in range(1,K+1) if target[g*K+r-1]}
                    assert structural.contains_sparse(compiled,sparse)==span.contains(target);targets+=1
                if G==2:
                    b=structural.binary_reference(c)
                    assert b['rank']==span.rank and b['legal_policies']==len(qs)
                total+=1;count+=1
            by_setting.append({'groups':G,'capacity':K,'all_feasible_box_contracts_checked':count})
    exact.save_csv(context['run']/'tables/exhaustive_geometry.csv',by_setting)
    check(context,'All feasible small boxes: interval compiler, exact rank, forest support, targets, and analytic binary baseline',total,
          exact_target_checks=targets)
    return {'contracts':total,'exact_target_checks':targets,'settings':by_setting}


def sensitivity_contracts():
    cases=[]
    for a,b in [(0,10),(0,8),(1,9),(2,8),(4,6),(5,5),(0,1),(3,4)]:
        cases.append({'id':f'binary_{a}_{b}','G':2,'K':10,'lo':[a,10-b],'hi':[b,10-a]})
    for K in (5,20):cases.append({'id':f'binary_K{K}','G':2,'K':K,'lo':[0,0],'hi':[K,K]})
    for hi in (2,3,4,5,7,10):cases.append({'id':f'five_upper{hi}','G':5,'K':10,'lo':[0]*5,'hi':[hi]*5})
    for lo,hi in [(1,2),(1,3),(1,4),(1,6),(2,2)]:
        cases.append({'id':f'five_lower{lo}_upper{hi}','G':5,'K':10,'lo':[lo]*5,'hi':[hi]*5})
    for lo,hi in [([0,0,0,0,0],[1,2,3,4,5]),([0,1,0,2,0],[2,4,5,4,6]),([2,0,0,0,0],[2,4,4,4,4])]:
        cases.append({'id':f'asymmetric_{len(cases)}','G':5,'K':10,'lo':lo,'hi':hi})
    return cases


def policy_sensitivity(context):
    rows=[]
    for c in sensitivity_contracts():
        compiled=structural.compile_box(c);qs=enumerate_legal(c)
        A=[exact.policy_row(q,c['K']) for q in qs];span=exact.ExactSpan(A)
        assert span.rank==compiled['rank'] and len(qs)==compiled['policy_count']
        v=len(compiled['vertices']);m=compiled['mandatory_count'];pruned=v+int(m>0)
        individually=sum(span.contains([int(j==i) for j in range(c['G']*c['K'])]) for i in range(c['G']*c['K']))
        assert individually==structural.individually_recoverable(compiled)
        rows.append({'contract':c['id'],'groups':c['G'],'capacity':c['K'],'lower':json.dumps(c['lo']),
            'upper':json.dumps(c['hi']),'legal_policies':len(qs),'reachable_positions':compiled['reachable_count'],
            'mandatory_positions':m,'components':len(compiled['components']),'minimum_linear_dimension':compiled['rank'],
            'reachable_individual_coordinates_linearly_recoverable':individually,
            'raw_counters':c['G']*c['K'],'pruned_counters':pruned,'all_answer_counters':len(qs),'forest_counters':compiled['rank'],
            'raw_additional_linear_dimensions':c['G']*c['K']-compiled['rank'],
            'pruned_additional_linear_dimensions':pruned-compiled['rank'],
            'unavoidably_recoverable_pairwise_contrasts':sum(math.comb(len(v),2) for v in compiled['components']),
            'all_answers_additional_linear_dimensions':0,'forest_additional_linear_dimensions':0,
            'source_feasibility_is_separately_demonstrated_only_for_M1':True})
    exact.save_csv(context['run']/'tables/policy_sensitivity.csv',rows)
    context['sensitivity']=rows
    check(context,'Predeclared quota sensitivity: exact matrix agrees with structural compiler',len(rows))
    return rows


def dense_reference(c):
    G,K,lo,hi=c['G'],c['K'],c['lo'],c['hi'];sl,sh=sum(lo),sum(hi)
    lower=[max(lo[g],K-sh+hi[g]) for g in range(G)]
    upper=[min(hi[g],K-sl+lo[g]) for g in range(G)]
    verts=[(g,r) for g in range(G) for r in range(lower[g]+1,upper[g]+1)]
    idx={v:i for i,v in enumerate(verts)};uf=structural.DSU(len(verts))
    for g in range(G):
        for h in range(g+1,G):
            low,high=sl-lo[g]-lo[h],sh-hi[g]-hi[h]
            for r in range(lower[g]+1,upper[g]+1):
                for s in range(lower[h]+1,upper[h]+1):
                    if low<=K-r+1-s<=high:uf.union(idx[(g,r)],idx[(h,s)])
    return 1+len(verts)-len({uf.find(i) for i in range(len(verts))})


def scalability(context,config):
    records=[];skips=[]
    for G in (2,5):
        for K in config['scalability_capacities']:
            c={'G':G,'K':K,'lo':[0]*G,'hi':[K]*G};npol=math.comb(K+G-1,G-1)
            expected=K+1 if G==2 else G*K
            functions=[('interval_forest',lambda:structural.compile_box(c)['rank'],'forest,components,base,exact_policy_count')]
            if K<=config['dense_capacity_cap']:functions.append(('dense_transfer_components',lambda:dense_reference(c),'rank_only'))
            else:skips.append({'groups':G,'capacity':K,'method':'dense_transfer_components','reason':'predeclared capacity cap'})
            if npol*G*K<=config['explicit_matrix_cell_cap']:
                functions.append(('explicit_rational_matrix',lambda:exact.ExactSpan([exact.policy_row(q,K) for q in enumerate_legal(c)]).rank,'rank_only'))
            else:skips.append({'groups':G,'capacity':K,'method':'explicit_rational_matrix','reason':'predeclared matrix cell cap; no timeout/speedup inferred'})
            if G==2:functions.append(('binary_analytic_rank',lambda:structural.binary_reference(c)['rank'],'rank_only'))
            else:functions.append(('unrestricted_analytic_rank',lambda:G*K,'rank_only; applicable only to unrestricted G>=3 family'))
            for method,fn,scope in functions:
                for rep in range(config['timing_repetitions']):
                    t=time.perf_counter_ns();rank=fn();elapsed=time.perf_counter_ns()-t
                    assert rank==expected
                    records.append({'groups':G,'capacity':K,'legal_policy_count':npol,'method':method,
                        'output_scope':scope,'replicate':rep,'elapsed_ns':elapsed,'exact_rank':rank,
                        'dimension_verified':True,'timing_is_environment_specific':True})
    exact.save_csv(context['run']/'tables/scalability_raw.csv',records)
    exact.save_csv(context['run']/'tables/scalability_skips.csv',skips)
    summary=[]
    keys=sorted({(r['groups'],r['capacity'],r['method']) for r in records})
    for G,K,method in keys:
        group=[r for r in records if (r['groups'],r['capacity'],r['method'])==(G,K,method)]
        ns=[r['elapsed_ns'] for r in group]
        summary.append({'groups':G,'capacity':K,'method':method,'legal_policies':group[0]['legal_policy_count'],
                        'median_ms':statistics.median(ns)/1e6,'minimum_ms':min(ns)/1e6,
                        'maximum_ms':max(ns)/1e6,'repetitions':len(ns),'output_scope':group[0]['output_scope']})
    exact.save_csv(context['run']/'tables/scalability_summary.csv',summary)
    context['scalability']=summary
    check(context,'Scalability: every measured method agrees with applicable analytic rank',len(records))
    return summary


def negative_reconstruction_controls(context):
    info=context['analyses']['M0'];plan=exact.make_graph_query_plan(info)
    vals=context['bundles']['M0']['AllPolicyMaterialise']['values']
    catalogue={q:tuple(v[i] for v in vals) for i,q in enumerate(info['policies'])}
    response={q:catalogue[q] for q in plan['queries']}
    incomplete=dict(response);incomplete.pop(plan['base_policy'])
    try:exact.recover_from_legal_answers(plan,incomplete)
    except ValueError:pass
    else:raise AssertionError('missing query accepted')
    perturbed=dict(response);perturbed[plan['base_policy']]=tuple(x+1 for x in response[plan['base_policy']])
    try:
        assert exact.recover_from_legal_answers(plan,perturbed)!=exact.recover_from_legal_answers(plan,response)
    except ArithmeticError:pass
    check(context,'M0 negative controls reject missing answers and detect perturbed answers',2)


def mutation_controls(context):
    import shutil,tempfile
    with tempfile.TemporaryDirectory(prefix='retainq_certificate_control_') as temporary:
        dest=Path(temporary)/'bundles/M1_RetainQForest_binary_rep0';dest.mkdir(parents=True)
        original=context['run']/'inputs/bundles/M1_RetainQForest_binary_rep0'
        for p in original.iterdir():shutil.copyfile(p,dest/p.name)
        state=dest/'retained_state.bin';before=state.read_bytes();changed=bytearray(before);changed[0]^=1;state.write_bytes(changed)
        try:exact.read_bundle(temporary,'M1','RetainQForest')
        except AssertionError:pass
        else:raise AssertionError('corrupted retained payload accepted')
        state.write_bytes(before)
        decoder=dest/'decoder.json';decoder.write_text(decoder.read_text()+' ')
        try:exact.read_bundle(temporary,'M1','RetainQForest')
        except AssertionError:pass
        else:raise AssertionError('corrupted decoder accepted')
    for c in [{'G':2,'K':10,'lo':[6,6],'hi':[10,10]}, {'G':2,'K':10,'lo':[0,0],'hi':[11,10]}]:
        try:structural.compile_box(c)
        except ValueError:pass
        else:raise AssertionError('invalid quota contract accepted')
    check(context,'Mutation controls reject altered payload/decoder and invalid contracts',4)


def figures(context):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'figure.dpi':120,'savefig.dpi':300,'pdf.fonttype':42,
                         'axes.spines.top':False,'axes.spines.right':False})
    out=context['run']/'figures';out.mkdir(exist_ok=True)
    fig,axes=plt.subplots(1,3,figsize=(13,3.6),layout='constrained')
    D=context['source_directions'];image=axes[0].imshow(D,aspect='auto',cmap='RdBu_r',vmin=-1,vmax=1)
    axes[0].axvline(9.5,color='black',lw=.8)
    axes[0].set_xticks([0,9,10,19],['0:1','0:10','1:1','1:10'],rotation=45,ha='right');axes[0].set_xlabel('Group : rank position')
    axes[0].set_yticks([0,4,8],[1,5,9]);axes[0].set_ylabel('Independent source-feasible direction')
    axes[0].set_title('(a) Full year-metric kernel is feasible')
    fig.colorbar(image,ax=axes[0],fraction=.045,ticks=[-1,0,1],label='Aggregate change')
    states=context['representation_worlds'];axes[1].bar(range(4),[x['distinct_states_across_512_feasible_worlds'] for x in states],color=['#888888','#d4a23e','#8667a5','#236a87'])
    axes[1].set_xticks(range(4),['Raw','Pruned','All answers','Forest'],rotation=15)
    axes[1].set_ylim(0,590);axes[1].set_ylabel('Distinct retained states');axes[1].set_title('(b) Same 512 valid source worlds')
    for i,row in enumerate(states):axes[1].text(i,row['distinct_states_across_512_feasible_worlds']+9,str(row['distinct_states_across_512_feasible_worlds']),ha='center')
    source=context['bundles']['M1']['RawRankMarginals']['values'];base=np.array(source,dtype=np.int64)
    A=np.array(context['analyses']['M1']['rows'],dtype=np.int64);answers=base@A.T
    axes[2].plot(range(11),answers[1],color='#236a87',lw=3,label='Observed history')
    axes[2].plot(range(11),(base[1]+context['source_directions'].sum(axis=0))@A.T,'o--',color='#d4a23e',ms=4,label='36 substitutions')
    axes[2].set_xlabel('Pre-2000 quota');axes[2].set_ylabel('Cumulative release-year metric');axes[2].set_title('(c) All permitted answers coincide');axes[2].legend(fontsize=8)
    for suffix in ('png','pdf'):fig.savefig(out/f'fixed_catalogue_information.{suffix}',bbox_inches='tight')
    plt.close(fig)
    rows=context['sensitivity'];fig,axes=plt.subplots(1,2,figsize=(12,3.8),layout='constrained')
    x=np.arange(len(rows))
    axes[0].plot(x,[r['reachable_positions'] for r in rows],'o-',label='Reachable positions',color='#888888')
    axes[0].plot(x,[r['minimum_linear_dimension'] for r in rows],'s-',label='Authorised answer rank',color='#236a87')
    axes[0].plot(x,[r['reachable_individual_coordinates_linearly_recoverable'] for r in rows],'^--',label='Recoverable individual coordinates',color='#d4a23e')
    axes[0].set_ylabel('Positions / independent dimensions');axes[0].legend(fontsize=8);axes[0].set_title('(a) Contract geometry changes retention')
    for kind,label,color in [('pruned','Pruned','#d4a23e'),('all_answers','All answers','#8667a5'),('forest','Forest','#236a87')]:
        axes[1].plot(x,[r[kind+'_additional_linear_dimensions'] for r in rows],'o-' if kind=='pruned' else '--',label=label,color=color)
    axes[1].set_ylabel('Additional independent linear dimensions');axes[1].set_title('(b) Retained information beyond answers');axes[1].legend(fontsize=8)
    for ax in axes:ax.set_xlabel('Predeclared contract index (CSV gives bounds)');ax.grid(axis='y',alpha=.18)
    for suffix in ('png','pdf'):fig.savefig(out/f'contract_sensitivity.{suffix}',bbox_inches='tight')
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11.5,3.6),layout='constrained')
    methods=[('interval_forest','Interval forest','#236a87'),
             ('dense_transfer_components','Dense transfer graph','#888888'),
             ('explicit_rational_matrix','Explicit rational matrix','#8667a5'),
             ('binary_analytic_rank','Binary rank formula','#d4a23e'),
             ('unrestricted_analytic_rank','Unrestricted rank formula','#d4a23e')]
    for ax,G in zip(axes,(2,5)):
        for method,label,color in methods:
            rows=sorted((r for r in context['scalability'] if r['groups']==G and r['method']==method),key=lambda r:r['capacity'])
            if rows:ax.plot([r['capacity'] for r in rows],[r['median_ms'] for r in rows],'o-',label=label,color=color,ms=3)
        ax.set_xscale('log');ax.set_yscale('log');ax.set_xlabel('Capacity K');ax.set_ylabel('Median time (ms, five repeats)')
        ax.set_title(f'G={G}; unrestricted quota family');ax.legend(fontsize=8);ax.grid(alpha=.18)
    for suffix in ('png','pdf'):fig.savefig(out/f'compiler_scalability.{suffix}',bbox_inches='tight')
    plt.close(fig)
