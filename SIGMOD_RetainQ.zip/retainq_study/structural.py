"""Quota compilation without policy enumeration; interval transfer graph scan."""
from __future__ import annotations
from collections import deque
import math


class DSU:
    def __init__(self, n): self.p = list(range(n)); self.sz = [1]*n
    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]; x = self.p[x]
        return x
    def union(self, x, y):
        x,y = self.find(x),self.find(y)
        if x == y: return False
        if self.sz[x] < self.sz[y]: x,y = y,x
        self.p[y] = x; self.sz[x] += self.sz[y]
        return True


def policy_count(lo, hi, K):
    # Prefix-sum bounded-composition DP, exact integers, O(G*K) arithmetic operations.
    dp = [1]+[0]*K
    for low, high in zip(lo, hi):
        prefix = [0]
        for value in dp: prefix.append(prefix[-1]+value)
        dp = [prefix[max(0,s-low+1)]-prefix[max(0,s-high)] for s in range(K+1)]
    return dp[K]


def compile_box(c):
    G,K = c['G'],c['K']; lo,hi = c['lo'],c['hi']
    if K < 1 or G < 1 or len(lo) != G or len(hi) != G: raise ValueError('shape')
    if any(not 0 <= a <= b <= K for a,b in zip(lo,hi)): raise ValueError('bounds')
    sl,sh = sum(lo),sum(hi)
    if not sl <= K <= sh: raise ValueError('infeasible quota family')
    lower = [max(lo[g],K-sh+hi[g]) for g in range(G)]
    upper = [min(hi[g],K-sl+lo[g]) for g in range(G)]
    vertices = [(g,r) for g in range(G) for r in range(lower[g]+1,upper[g]+1)]
    index = {v:i for i,v in enumerate(vertices)}; dsu = DSU(len(vertices)); forest = []
    scans = 0; candidates = 0; represented_edges = 0
    for g in range(G):
        for h in range(g+1,G):
            # An unprocessed cut joins consecutive donor positions. A single star
            # establishes each such cut once per group pair, without dense edges.
            nxt = list(range(K+2))
            def next_cut(x):
                while nxt[x] != x:
                    nxt[x] = nxt[nxt[x]]; x = nxt[x]
                return x
            residual_low, residual_high = sl-lo[g]-lo[h],sh-hi[g]-hi[h]
            for r in range(lower[g]+1,upper[g]+1):
                scans += 1
                left = max(lower[h]+1,K-r+1-residual_high)
                right = min(upper[h],K-r+1-residual_low)
                if left > right: continue
                represented_edges += right-left+1
                def add(s):
                    nonlocal candidates
                    candidates += 1
                    a,b = (g,r),(h,s)
                    if dsu.union(index[a],index[b]): forest.append((a,b))
                add(left)
                cut = next_cut(left)
                while cut < right:
                    add(cut+1)
                    nxt[cut] = next_cut(cut+1)
                    cut = next_cut(cut)
    components = {}
    for vertex,i in index.items(): components.setdefault(dsu.find(i),[]).append(vertex)
    comps = sorted(sorted(v) for v in components.values())
    component_id = {v:i for i,comp in enumerate(comps) for v in comp}
    base = list(lo); remaining = K-sum(base)
    for g in range(G):
        take = min(remaining,hi[g]-base[g]); base[g] += take; remaining -= take
    assert remaining == 0
    counts = [sum(r <= base[g] for g,r in comp) for comp in comps]
    assert all(x > 0 for x in counts)
    return {'G':G,'K':K,'lo':list(lo),'hi':list(hi),'lower':lower,'upper':upper,
            'vertices':vertices,'index':index,'components':comps,'component_id':component_id,
            'base':base,'counts':counts,'mandatory_count':sum(lower),
            'reachable_count':sum(upper),'rank':1+len(vertices)-len(comps),
            'forest':forest,'interval_scans':scans,'edge_candidates_inspected':candidates,
            'dense_transfer_edges_represented':represented_edges,
            'policy_count':policy_count(lo,hi,K)}


def contains_sparse(compiled, coefficients):
    """Exact target membership, sparse target keyed by (group, one-based rank)."""
    from fractions import Fraction
    sums = [Fraction(0)]*len(compiled['components']); mandatory = {}
    for (g,r),v in coefficients.items():
        if not v: continue
        if not 0 <= g < compiled['G'] or not 1 <= r <= compiled['K']: raise ValueError('target position')
        if r > compiled['upper'][g]: return False
        if r <= compiled['lower'][g]: mandatory[(g,r)] = Fraction(v)
        else: sums[compiled['component_id'][(g,r)]] += v
    if compiled['mandatory_count']:
        if len(mandatory) < compiled['mandatory_count']: alpha = Fraction(0)
        else: alpha = next(iter(mandatory.values()))
        if any(v != alpha for v in mandatory.values()): return False
    elif sums:
        alpha = sums[0]/compiled['counts'][0]
    else: return not coefficients
    return all(value == alpha*k for value,k in zip(sums,compiled['counts']))


def individually_recoverable(compiled):
    if compiled['mandatory_count'] == 0 and len(compiled['components']) == 1:
        return len(compiled['vertices'])
    return int(compiled['mandatory_count'] == 1 and not compiled['vertices'])


def binary_reference(c):
    """Strong analytic baseline for G=2; no graph or policy matrix required."""
    if c['G'] != 2: raise ValueError('binary baseline')
    K = c['K']; a=max(c['lo'][0],K-c['hi'][1]); b=min(c['hi'][0],K-c['lo'][1])
    if a>b:raise ValueError('infeasible')
    width=b-a
    return {'rank':width+1,'components':width,'variable_positions':2*width,
            'mandatory_positions':K-width,'legal_policies':width+1}
