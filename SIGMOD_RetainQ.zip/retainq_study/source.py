"""Fixed-catalogue MovieLens capture and feasible-history certificates."""
from __future__ import annotations
import bisect, collections, csv, hashlib, json, re, time, urllib.request, zipfile
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

SOURCE_URL = 'https://files.grouplens.org/datasets/movielens/ml-25m.zip'
EXPECTED_MD5 = '6b51fb2759a8657d3bfcbfc42b592ada'
EXPECTED_MOVIES_SHA256 = 'c50dea6973e619f9bc1decd4afa3e35358b83a5fb663dac0ec82252a011d023d'
EXPECTED_RATINGS_SHA256 = '9c85525758597dca76e8d98cebb9c13e018c2317b09a0878b6d383179526e385'
EXPECTED_ARCHIVE_SHA256 = '8b21cfb7eb1706b4ec0aac894368d90acf26ebdfb6aced3ebd4ad5bd1eb9c6aa'


def digest(path, algorithm='sha256'):
    h=hashlib.new(algorithm)
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()


def obtain_data(cache):
    cache=Path(cache);cache.mkdir(parents=True,exist_ok=True);archive=cache/'ml-25m.zip'
    if not archive.exists():
        part=archive.with_suffix('.zip.part')
        with urllib.request.urlopen(SOURCE_URL,timeout=60) as response,part.open('wb') as f:
            while True:
                b=response.read(8*1024*1024)
                if not b:break
                f.write(b)
        part.replace(archive)
    if digest(archive,'md5')!=EXPECTED_MD5:raise ValueError('official archive MD5 mismatch')
    with zipfile.ZipFile(archive) as z:
        for name in ('movies.csv','ratings.csv','README.txt'):
            target=cache/'ml-25m'/name
            if not target.exists():z.extract('ml-25m/'+name,cache)
    movies,ratings=cache/'ml-25m/movies.csv',cache/'ml-25m/ratings.csv'
    movie_hash,rating_hash,archive_hash=digest(movies),digest(ratings),digest(archive)
    if movie_hash!=EXPECTED_MOVIES_SHA256:raise ValueError('fixed catalogue mismatch')
    if rating_hash!=EXPECTED_RATINGS_SHA256:raise ValueError('fixed original ratings mismatch')
    if archive_hash!=EXPECTED_ARCHIVE_SHA256:raise ValueError('fixed official archive SHA256 mismatch')
    catalogue={};year_index=collections.defaultdict(list)
    with movies.open(newline='',encoding='utf-8') as f:
        for row in csv.DictReader(f):
            m=re.search(r'\(([0-9]{4})\)$',row['title']);year=int(m.group(1)) if m else 1900
            mid=int(row['movieId']);catalogue[mid]=year;year_index[year].append(mid)
    for ids in year_index.values():ids.sort()
    return {'movies':movies,'ratings':ratings,'catalogue':catalogue,'year_index':dict(year_index),
            'provenance':{'dataset':'ml-25m','source_url':SOURCE_URL,'archive_md5':EXPECTED_MD5,
                          'archive_sha256':archive_hash,'movies_sha256':movie_hash,
                          'ratings_sha256':rating_hash,'catalogue_movies':len(catalogue),
                          'raw_dataset_redistributed':False}}


def load_prefix(data, limit):
    rounds=collections.OrderedDict()
    with data['ratings'].open(newline='',encoding='utf-8') as f:
        for row in csv.DictReader(f):
            user=int(row['userId'])
            if user>limit:break
            twice=float(row['rating'])*2
            if not twice.is_integer() or not 1<=twice<=10:raise ValueError('invalid source rating')
            rounds.setdefault(user,[]).append((int(row['movieId']),int(twice),int(row['timestamp'])))
    return rounds


def ranked_groups(records,catalogue,G=2,K=10):
    groups=[[] for _ in range(G)]
    for mid,score,timestamp in records:
        year=catalogue[mid]
        g=int(year>=2000) if G==2 else (0 if year<1980 else 1 if year<1990 else 2 if year<2000 else 3 if year<2010 else 4)
        groups[g].append((mid,score,timestamp,year))
    return [sorted(g,key=lambda x:(-x[1],x[0]))[:K] for g in groups]


def round_atoms(records,catalogue,G=2,K=10):
    out=np.zeros((2,G*K),dtype=np.int64)
    for g,group in enumerate(ranked_groups(records,catalogue,G,K)):
        for r,(_,score,_,year) in enumerate(group):out[:,g*K+r]=(score,max(0,min(200,year-1900)))
    return out


def direct_round_answers(records,catalogue,policies):
    # Independent direct record-selection loop, not the atom/query matrix decoder.
    answer=[]
    for quota in policies:
        selected=[]
        for g,want in enumerate(quota):
            group=[v for v in records if int(catalogue[v[0]]>=2000)==g]
            group.sort(key=lambda v:(-v[1],v[0]));selected.extend(group[:want])
        answer.append([sum(v[1] for v in selected),sum(max(0,min(200,catalogue[v[0]]-1900)) for v in selected)])
    return np.array(answer,dtype=np.int64).T


def discover_moves(rounds,data,K=10,limit_per_label=256):
    pools=collections.defaultdict(dict)
    for user,records in rounds.items():
        ids={x[0] for x in records};groups=ranked_groups(records,data['catalogue'],2,K+1)
        for g,group in enumerate(groups):
            for j,old in enumerate(group[:K]):
                mid,score,timestamp,year=old
                low=group[j-1][0] if j and group[j-1][1]==score else -1
                high=group[j+1][0] if j+1<len(group) and group[j+1][1]==score else 10**12
                for shift in (-1,1):
                    label=(g,j+1,shift)
                    if len(pools[label])>=limit_per_label:continue
                    new_year=year+shift
                    if int(new_year>=2000)!=g or new_year>datetime.fromtimestamp(timestamp,timezone.utc).year:continue
                    options=data['year_index'].get(new_year,[])
                    a,b=bisect.bisect_right(options,low),bisect.bisect_left(options,high)
                    replacement=next((v for v in options[a:b] if v not in ids),None)
                    if replacement is None:continue
                    pools[label][user]={'user_id':user,'group':g,'rank':j+1,'old_movie_id':mid,
                        'new_movie_id':replacement,'twice_rating':score,'timestamp':timestamp,
                        'old_year':year,'new_year':new_year,'year_shift':shift}
    return dict(pools)


def select_disjoint_gadgets(pools,K=10):
    slots=[]
    for direction in range(1,K):
        for label in [(0,direction,1),(1,K+1-direction,1),(0,K,-1),(1,1,-1)]:
            slots.append((direction,label))
    assigned={};used={}
    def augment(slot,seen):
        for user in sorted(pools.get(slots[slot][1],{})):
            if user in seen:continue
            seen.add(user)
            if user not in used or augment(used[user],seen):
                used[user]=slot;assigned[slot]=user;return True
        return False
    for slot in range(len(slots)):
        if not augment(slot,set()):raise RuntimeError('predeclared search cannot realize all disjoint directions')
    edits=[]
    for slot,(direction,label) in enumerate(slots):
        edit=dict(pools[label][assigned[slot]]);edit.update(direction=direction,edit_id=slot)
        edits.append(edit)
    assert len({x['user_id'] for x in edits})==4*(K-1)
    return edits


def apply_edit(records,edit):
    changed=[];found=0
    for mid,score,timestamp in records:
        if mid==edit['old_movie_id']:
            assert score==edit['twice_rating'] and timestamp==edit['timestamp']
            changed.append((edit['new_movie_id'],score,timestamp));found+=1
        else:changed.append((mid,score,timestamp))
    assert found==1 and len({x[0] for x in changed})==len(changed)
    return changed


def sql_capture(data,work,edits=None):
    """Re-read original CSVs with a separate SQL parser and window-rank oracle."""
    import duckdb
    work=Path(work);work.mkdir(parents=True,exist_ok=True)
    db=duckdb.connect(':memory:');db.execute('SET threads=2');db.execute("SET memory_limit='1500MB'")
    db.execute('SET temp_directory=?',[str(work/'duckdb_tmp')])
    db.execute('CREATE TABLE catalogue AS SELECT movieId::BIGINT mid, coalesce(try_cast(regexp_extract(title, \'\\(([0-9]{4})\\)$\',1) AS INTEGER),1900) yr FROM read_csv_auto(?)',[str(data['movies'])])
    replacement='r.movieId'
    if edits:
        db.execute('CREATE TABLE edits(user_id BIGINT,old_id BIGINT,new_id BIGINT)')
        db.executemany('INSERT INTO edits VALUES (?,?,?)',[(e['user_id'],e['old_movie_id'],e['new_movie_id']) for e in edits])
        replacement='coalesce(e.new_id,r.movieId)'
    join='LEFT JOIN edits e ON r.userId=e.user_id AND r.movieId=e.old_id' if edits else ''
    db.execute(f'''CREATE TABLE source_rows AS
        SELECT r.userId::BIGINT user_id, {replacement}::BIGINT movie_id,
               round(r.rating*2)::BIGINT score, r.timestamp::BIGINT event_time
        FROM read_csv_auto(?) r {join}''',[str(data['ratings'])])
    counts=db.execute('SELECT count(*),count(DISTINCT user_id),min(score),max(score) FROM source_rows').fetchone()
    duplicates=db.execute('SELECT count(*) FROM (SELECT user_id,movie_id FROM source_rows GROUP BY ALL HAVING count(*)>1)').fetchone()[0]
    missing=db.execute('SELECT count(*) FROM source_rows s ANTI JOIN catalogue c ON s.movie_id=c.mid').fetchone()[0]
    assert counts[0]==25000095 and counts[1]==162541 and counts[2:]==(1,10) and duplicates==missing==0
    captures={};direct={};horizons=[100,1000,10000,162541]
    for G in (2,5):
        group='CASE WHEN c.yr<2000 THEN 0 ELSE 1 END' if G==2 else 'CASE WHEN c.yr<1980 THEN 0 WHEN c.yr<1990 THEN 1 WHEN c.yr<2000 THEN 2 WHEN c.yr<2010 THEN 3 ELSE 4 END'
        db.execute(f'''CREATE TEMP TABLE ranked AS SELECT * FROM
            (SELECT s.*,c.yr,{group} g,
             row_number() OVER(PARTITION BY s.user_id,{group} ORDER BY s.score DESC,s.movie_id ASC) r
             FROM source_rows s JOIN catalogue c ON s.movie_id=c.mid) WHERE r<=10''')
        for horizon in horizons:
            arr=np.zeros((2,G*10),dtype=np.int64)
            for g,r,a,b in db.execute('SELECT g,r,sum(score),sum(greatest(0,least(200,yr-1900))) FROM ranked WHERE user_id<=? GROUP BY g,r',[horizon]).fetchall():
                arr[:,g*10+r-1]=(a,b)
            captures[(G,horizon)]=arr
        if G==2:
            policies=[(i,10-i) for i in range(11)]
            # Direct selection predicates over independently ranked source rows.
            clauses=[f'SELECT {i} q,sum(score)::BIGINT a,sum(greatest(0,least(200,yr-1900)))::BIGINT b FROM ranked WHERE (g=0 AND r<={q[0]}) OR (g=1 AND r<={q[1]})' for i,q in enumerate(policies)]
            answers=db.execute(' UNION ALL '.join(clauses)+' ORDER BY q').fetchall()
            direct[G]=np.array([[row[1] for row in answers],[row[2] for row in answers]],dtype=np.int64)
        db.execute('DROP TABLE ranked')
    db.close()
    return {'captures':captures,'direct':direct,'source_rows':counts[0],'source_rounds':counts[1],
            'duplicate_user_movie_pairs':duplicates,'unknown_movies':missing}
