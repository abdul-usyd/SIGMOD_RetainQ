"""Anonymized RetainQ information-retention study."""
