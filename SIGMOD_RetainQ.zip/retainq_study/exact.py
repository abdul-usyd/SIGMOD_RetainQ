"""Exact rational reference implementation; no producer imports."""

from __future__ import annotations

import collections, csv, hashlib, itertools, json, math, random, struct
from fractions import Fraction
from pathlib import Path

CASES = ('A0','A1','M0','M1')
KINDS = ('RawRankMarginals','PrunedRankMarginals','AllPolicyMaterialise','RetainQForest')

def dump_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding='utf-8')

def save_csv(path, rows):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('', encoding='utf-8'); return
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for row in rows for k in row)))
        writer.writeheader(); writer.writerows(rows)

def sha(data):
    return hashlib.sha256(data).hexdigest()

class ExactSpan:
    """Independent rational row elimination; no floating-point rank decisions."""
    def __init__(self, rows, width=None):
        self.width = len(rows[0]) if rows else int(width or 0)
        self.pivots = {}; self.selected = []
        for index, row in enumerate(rows):
            if len(row) != self.width: raise ValueError('row width')
            remainder = self.reduce(row)
            pivot = next((j for j, x in enumerate(remainder) if x), None)
            if pivot is not None:
                scale = remainder[pivot]
                self.pivots[pivot] = [x / scale for x in remainder]
                self.selected.append(index)
        self.rank = len(self.pivots)

    def reduce(self, row):
        result = [Fraction(x) for x in row]
        for pivot in sorted(self.pivots):
            factor = result[pivot]
            if factor:
                basis = self.pivots[pivot]
                result = [x-factor*y for x, y in zip(result, basis)]
        return result

    def contains(self, row):
        return not any(self.reduce(row))

def invert_exact(matrix):
    n = len(matrix)
    if not n or any(len(row) != n for row in matrix): raise ValueError('square matrix required')
    a = [[Fraction(x) for x in row] + [Fraction(i == j) for j in range(n)]
         for i, row in enumerate(matrix)]
    for column in range(n):
        pivot = next((i for i in range(column, n) if a[i][column]), None)
        if pivot is None: raise ValueError('singular matrix')
        a[column], a[pivot] = a[pivot], a[column]
        factor = a[column][column]; a[column] = [x/factor for x in a[column]]
        for i in range(n):
            if i != column and a[i][column]:
                factor = a[i][column]
                a[i] = [x-factor*y for x, y in zip(a[i], a[column])]
    inverse = [row[n:] for row in a]
    for i in range(n):
        for j in range(n):
            assert sum(Fraction(matrix[i][k])*inverse[k][j] for k in range(n)) == (i == j)
    return inverse

def exact_integer(x):
    x = Fraction(x)
    if x.denominator != 1: raise ArithmeticError('expected an exact integer')
    return x.numerator

def evaluate_rows(rows, values):
    # values[metric][atom], rows[retained/query coordinate][atom]
    return [[sum(int(a)*int(x) for a, x in zip(row, metric)) for row in rows]
            for metric in values]

def policy_list(contract):
    # Independent Cartesian-product enumeration. Only the four small frozen families.
    size = math.prod(u-l+1 for l, u in zip(contract['lo'], contract['hi']))
    if size > 1_000_000: raise ValueError('focused explicit-policy cap')
    return [q for q in itertools.product(*(range(l, u+1) for l, u in zip(contract['lo'], contract['hi'])))
            if sum(q) == contract['K']]

def policy_row(q, K):
    return [int(r <= q[g]) for g in range(len(q)) for r in range(1, K+1)]

def analyze_contract(contract):
    policies = policy_list(contract)
    if not policies: raise ValueError('empty policy family')
    G, K = contract['G'], contract['K']; n = G*K
    positions = [(g, r) for g in range(G) for r in range(1, K+1)]
    columns = {p: i for i, p in enumerate(positions)}
    rows = [policy_row(q, K) for q in policies]
    minima = [min(q[g] for q in policies) for g in range(G)]
    maxima = [max(q[g] for q in policies) for g in range(G)]
    mandatory = [p for p in positions if p[1] <= minima[p[0]]]
    variables = [p for p in positions if minima[p[0]] < p[1] <= maxima[p[0]]]
    unreachable = set(positions)-set(mandatory)-set(variables)
    policyset = set(policies); neighbors = {q: [] for q in policies}; witnesses = {}
    for q in policies:
        for g in range(G):
            for h in range(G):
                if g == h: continue
                other = list(q); other[g] += 1; other[h] -= 1; other = tuple(other)
                if other not in policyset: continue
                added, removed = (g, q[g]+1), (h, q[h])
                assert added in variables and removed in variables
                neighbors[q].append(other)
                key = tuple(sorted((added, removed)))
                witnesses.setdefault(key, {'q_from': q, 'q_to': other, 'added': added, 'removed': removed})
    seen = {policies[0]}; todo = collections.deque(seen)
    while todo:
        for other in neighbors[todo.popleft()]:
            if other not in seen: seen.add(other); todo.append(other)
    if len(seen) != len(policies): raise ValueError('unit-transfer policy graph is disconnected')
    adjacency = {p: set() for p in variables}
    for left, right in witnesses:
        adjacency[left].add(right); adjacency[right].add(left)
    components = []; oriented = []; seen = set()
    for root in variables:
        if root in seen: continue
        component = []; todo = collections.deque([root]); seen.add(root)
        while todo:
            parent = todo.popleft(); component.append(parent)
            for child in sorted(adjacency[parent]):
                if child in seen: continue
                seen.add(child); todo.append(child)
                witness = witnesses[tuple(sorted((parent, child)))]
                oriented.append({'parent': parent, 'child': child,
                                 'sign': 1 if witness['added'] == child else -1, **witness})
        components.append(sorted(component))
    span = ExactSpan(rows, n)
    rho = 1+len(variables)-len(components)
    assert span.rank == rho
    assert all(len(x) >= 2 for x in components)
    return {'contract': contract, 'policies': policies, 'rows': rows, 'positions': positions,
            'columns': columns, 'minima': minima, 'maxima': maxima, 'mandatory': mandatory,
            'variables': variables, 'unreachable': unreachable, 'components': components,
            'oriented': oriented, 'span': span, 'rho': rho}

def structural_membership(info, target):
    """Corollary: component sums must match one multiple of the base row."""
    c = info['columns']
    if any(target[c[p]] for p in info['unreachable']): return False
    mandatory_values = [Fraction(target[c[p]]) for p in info['mandatory']]
    base = info['policies'][0]
    counts = [sum(r <= base[g] for g, r in comp) for comp in info['components']]
    if mandatory_values:
        alpha = mandatory_values[0]
        if any(x != alpha for x in mandatory_values): return False
    elif counts:
        assert counts[0] > 0
        alpha = sum(Fraction(target[c[p]]) for p in info['components'][0])/counts[0]
    else:
        return not any(target)
    return all(sum(Fraction(target[c[p]]) for p in comp) == alpha*k
               for comp, k in zip(info['components'], counts))

def representation_rows(info, kind, decoder=None):
    n = len(info['positions']); index = info['columns']
    if kind == 'AllPolicyMaterialise': return info['rows']
    if kind == 'RawRankMarginals':
        return [[int(i == j) for j in range(n)] for i in range(n)]
    if kind == 'PrunedRankMarginals':
        result = []
        if info['mandatory']:
            result.append([int(p in info['mandatory']) for p in info['positions']])
        result.extend([[int(p == v) for p in info['positions']] for v in info['variables']])
        return result
    if kind != 'RetainQForest' or decoder is None: raise ValueError('representation')
    result = [policy_row(decoder['q0'], info['contract']['K'])]
    for edge in decoder['oriented_edges']:
        row = [0]*n
        row[index[tuple(edge['child'])]] = 1; row[index[tuple(edge['parent'])]] = -1
        result.append(row)
    return result

def read_bundle(root, case, kind):
    folder = Path(root)/'bundles'/f'{case}_{kind}_binary_rep0'
    c = json.loads((folder/'contract.json').read_text())
    d = json.loads((folder/'decoder.json').read_text())
    cert = json.loads((folder/'certificate.json').read_text())
    data = (folder/'retained_state.bin').read_bytes(); dim = d['dimension']
    assert len(data) == c['metrics']*dim*8
    flat = list(struct.unpack('<'+'q'*(len(data)//8), data))
    values = [flat[m*dim:(m+1)*dim] for m in range(c['metrics'])]
    for filename, field in [('contract.json','contract_sha256'), ('decoder.json','decoder_sha256'),
                            ('retained_state.bin','state_sha256')]:
        assert sha((folder/filename).read_bytes()) == cert[field]
    return {'contract': c, 'decoder': d, 'certificate': cert, 'values': values,
            'bundle_bytes': sum(p.stat().st_size for p in folder.iterdir()), 'payload_bytes': len(data)}

def audit_representations(context):
    exposure = []; representation = []; target_rows = []; rng = random.Random(20261018)
    for case in CASES:
        bundles = context['bundles'][case]; c = bundles[KINDS[0]]['contract']
        info = analyze_contract(c); context['analyses'][case] = info
        reference = bundles['RawRankMarginals']['values']
        exact_spans = {}
        for kind in KINDS:
            bundle = bundles[kind]; E = representation_rows(info, kind, bundle['decoder'])
            assert evaluate_rows(E, reference) == bundle['values'], (case, kind, 'frozen state mismatch')
            E_span = ExactSpan(E, len(info['positions'])); exact_spans[kind] = E_span
            combined = ExactSpan(info['rows']+E, len(info['positions']))
            assert all(E_span.contains(row) for row in info['rows'])
            extra = combined.rank-info['rho']
            if kind in ('AllPolicyMaterialise','RetainQForest'): assert extra == 0
            representation.append({'case':case, 'representation':kind,
                'stored_counters_per_metric':len(E), 'independent_information_dimension_per_metric':E_span.rank,
                'authorised_answer_rank_per_metric':info['rho'],
                'additional_linear_dimensions_per_metric':extra,
                'v6_value_payload_bytes_rep0':bundle['payload_bytes'],
                'v6_complete_binary_bundle_bytes_rep0':bundle['bundle_bytes'],
                'all_authorised_answers_supported':True, 'matches_frozen_values':True,
                'physical_sizes_source':'Existing V6 binary rep0; not a new performance measurement'})
        identifiable = 0; reachable_identifiable = 0; check_count = 0
        candidates = []
        for j, (g, r) in enumerate(info['positions']):
            target = [int(j == i) for i in range(len(info['positions']))]
            candidates.append(target)
            determined = info['span'].contains(target); structural = structural_membership(info, target)
            assert determined == structural
            identifiable += int(determined)
            reachable = (g, r) not in info['unreachable']; reachable_identifiable += int(determined and reachable)
            target_rows.append({'case':case, 'target':f'group_{g}_rank_{r}', 'group':g, 'rank_position':r,
                'reachable':reachable, 'mandatory':(g,r) in info['mandatory'],
                'universally_linearly_determined_by_authorised_answers':determined,
                'structural_rule_agrees_with_exact_elimination':True,
                'determined_by_pruned_state':exact_spans['PrunedRankMarginals'].contains(target),
                'determined_by_retainq_state':exact_spans['RetainQForest'].contains(target),
                'privacy_guarantee':False})
        for _ in range(24):
            chosen = [rng.randrange(len(info['rows'])) for _ in range(3)]
            weights = [rng.randint(-2,2) for _ in chosen]
            target = [sum(w*info['rows'][i][j] for w,i in zip(weights,chosen))
                      for j in range(len(info['positions']))]
            assert info['span'].contains(target); candidates.append(target)
        for _ in range(24):
            candidates.append([rng.randint(-1,1) if p not in info['unreachable'] else 0
                               for p in info['positions']])
        candidates.append([int(p in info['mandatory']) for p in info['positions']])
        for target in candidates:
            assert structural_membership(info,target) == info['span'].contains(target)
            check_count += 1
        exposure.append({'case':case, 'G':c['G'], 'K':c['K'], 'legal_policies':len(info['policies']),
            'full_rank_positions':len(info['positions']),
            'reachable_positions':len(info['mandatory'])+len(info['variables']),
            'mandatory_positions':len(info['mandatory']), 'variable_positions':len(info['variables']),
            'transfer_components':len(info['components']), 'minimum_linear_dimension_per_metric':info['rho'],
            'identifiable_reachable_individual_rank_statistics':reachable_identifiable,
            'all_reachable_statistics_linearly_reconstructible':reachable_identifiable == len(info['mandatory'])+len(info['variables']),
            'structural_membership_checks':check_count,
            'linear_membership_is_not_a_privacy_guarantee':True})
        context['checks'].append({'check':f'{case}: four frozen representations and exact structural membership',
                                  'passed':True, 'count':check_count})
    save_csv(context['run']/'tables/contract_information.csv', exposure)
    save_csv(context['run']/'tables/representation_information.csv', representation)
    save_csv(context['run']/'tables/rank_statistic_membership.csv', target_rows)
    context.update(exposure=exposure, representation=representation, target_rows=target_rows)
    return exposure

def make_graph_query_plan(info):
    if info['mandatory'] or len(info['components']) != 1:
        raise ValueError('full individual reconstruction requires no mandatory positions and one component')
    base = info['policies'][0]; queries = {base}
    for edge in info['oriented']:
        queries.add(edge['q_from']); queries.add(edge['q_to'])
    assert len(queries) <= 2*info['rho']-1
    return {'base_policy':base, 'root':info['components'][0][0], 'edges':info['oriented'],
            'queries':sorted(queries), 'variables':info['variables'], 'K':info['contract']['K']}

def recover_from_legal_answers(plan, permitted_responses):
    """Only public query design + selected legal responses; no reference states."""
    if set(permitted_responses) != set(plan['queries']): raise ValueError('response/query mismatch')
    metrics = len(permitted_responses[plan['base_policy']]); recovered = []
    for m in range(metrics):
        potentials = {plan['root']:0}
        for edge in plan['edges']:
            delta = edge['sign']*(permitted_responses[edge['q_to']][m]-permitted_responses[edge['q_from']][m])
            potentials[edge['child']] = potentials[edge['parent']]+delta
        base = plan['base_policy']
        selected_potential_sum = sum(value for (g,r),value in potentials.items() if r <= base[g])
        root_value = Fraction(permitted_responses[base][m]-selected_potential_sum, plan['K'])
        recovered.append({p:exact_integer(root_value+potentials[p]) for p in plan['variables']})
    return recovered

def reconstruction_experiment(context):
    info = context['analyses']['M0']; source = context['bundles']['M0']['AllPolicyMaterialise']
    catalog = {q:tuple(source['values'][m][i] for m in range(info['contract']['metrics']))
               for i,q in enumerate(info['policies'])}
    plan = make_graph_query_plan(info)
    selected_responses = {q:catalog[q] for q in plan['queries']}
    reconstructed = recover_from_legal_answers(plan, selected_responses)
    # Independent classical baseline: choose a rationally independent set of legal rows.
    variable_cols = [info['columns'][p] for p in info['variables']]
    reduced_rows = [[row[j] for j in variable_cols] for row in info['rows']]
    independent = ExactSpan(reduced_rows); selected = independent.selected
    assert len(selected) == len(info['variables']) == info['rho']
    inverse = invert_exact([reduced_rows[i] for i in selected])
    matrix_reconstruction = []
    for m in range(info['contract']['metrics']):
        y = [catalog[info['policies'][i]][m] for i in selected]
        matrix_reconstruction.append({p:exact_integer(sum(inverse[j][i]*y[i] for i in range(len(y))))
                                      for j,p in enumerate(info['variables'])})
    # Reference accessed only after both attacks have produced their results.
    reference = context['bundles']['M0']['RawRankMarginals']['values']; rows = []
    for m in range(info['contract']['metrics']):
        for p in info['variables']:
            truth = reference[m][info['columns'][p]]
            assert reconstructed[m][p] == matrix_reconstruction[m][p] == truth
            rows.append({'metric':info['contract']['semantics']['observables'][m],
                         'group':p[0], 'rank_position':p[1], 'reference_cumulative_value':truth,
                         'reconstructed_from_graph_query_answers':reconstructed[m][p],
                         'reconstructed_from_independent_query_basis':matrix_reconstruction[m][p],
                         'graph_absolute_error':abs(reconstructed[m][p]-truth),
                         'independent_absolute_error':abs(matrix_reconstruction[m][p]-truth)})
    save_csv(context['run']/'tables/M0_reconstruction.csv',rows)
    def save_queries(filename, query_list):
        save_csv(context['run']/'tables'/filename,
            [{'query_id':i,'quota':json.dumps(q),**{f'metric_{m}_answer':catalog[q][m]
                for m in range(info['contract']['metrics'])}} for i,q in enumerate(query_list)])
    save_queries('M0_graph_permitted_queries.csv',plan['queries'])
    basis_queries = [info['policies'][i] for i in selected]
    save_queries('M0_independent_basis_queries.csv',basis_queries)
    # Complete, source-independent evidence: each target is a linear combination of legal answers.
    dump_json(context['run']/'evidence/M0_graph_query_design.json',plan)
    dump_json(context['run']/'evidence/M0_independent_decoder.json',{
        'queries':basis_queries, 'target_positions':info['variables'],
        'exact_decoder':[[str(x) for x in row] for row in inverse],
        'metric_independent':True, 'reference_values_used_to_construct_decoder':False})
    summary = {'case':'M0','legal_family_size':len(info['policies']),
               'reachable_statistics_per_metric':len(info['variables']),
               'metrics':info['contract']['metrics'], 'graph_queries_used':len(plan['queries']),
               'graph_query_upper_bound':2*info['rho']-1, 'independent_basis_queries_used':len(selected),
               'exactly_reconstructed_values':len(rows), 'maximum_absolute_error':0,
               'reconstruction_input':'only permitted answers and public query design',
               'individual_records_or_identities_reconstructed':False}
    context['reconstruction'] = summary
    context['checks'].append({'check':'M0: graph and independent legal-query attacks match all references',
                              'passed':True,'count':len(rows)})
    return summary
